package com.amresalehin.emregallery.data

data class MediaProvenance(
    val extractorEngine: String = "Static HTML",
    val pageUrl: String = "",
    val domSelector: String? = null
)

/**
 * Represents a single URL variant (e.g. a srcset candidate, <source> element, or data-src attribute)
 * belonging to a structured media resource on a page.
 */
data class MediaVariantCandidate(
    val url: String,
    val descriptor: String? = null,
    val width: Int? = null,
    val height: Int? = null,
    val mimeType: String? = null,
    val source: ExtractionSource = ExtractionSource.DOM_SCRAPE
)

/**
 * Structured representation of a discovered media resource prior to or during normalization.
 * Captures the full resource context (variants, explicit thumbnail/poster relationships,
 * media type & MIME hints from DOM/JSON-LD/OpenGraph, dimensions, and semantic metadata)
 * rather than treating media discovery as flat URL extraction.
 */
data class DiscoveredMediaResource(
    val primaryUrl: String,
    val variants: List<MediaVariantCandidate> = emptyList(),
    val thumbnailUrl: String? = null,
    val companionUrls: List<String> = emptyList(),
    val source: ExtractionSource = ExtractionSource.DOM_SCRAPE,
    val mediaTypeHint: String? = null,
    val mimeHint: String? = null,
    val titleHint: String? = null,
    val descriptionHint: String? = null,
    val authorHint: String? = null,
    val durationSeconds: Long? = null,
    val width: Int? = null,
    val height: Int? = null,
    val resolutionHint: String? = null,
    val sizeBytes: Long? = null,
    val domSelector: String? = null,
    val resourceGroupId: String? = null,
    val metadata: Map<String, String> = emptyMap()
)

data class ScrapedMediaItem(
    val id: String,
    val url: String,
    val title: String,
    val isVideo: Boolean = false,
    val isAudio: Boolean = false,
    val isStream: Boolean = false,
    val category: MediaCategory = when {
        isStream -> MediaCategory.STREAMS
        isVideo -> MediaCategory.VIDEOS
        isAudio -> MediaCategory.AUDIO
        else -> MediaCategory.IMAGES
    },
    val format: String = when {
        isStream -> "HLS/DASH"
        isVideo -> "MP4"
        isAudio -> "AUDIO"
        else -> "IMAGE"
    },
    val thumbnailUrl: String? = null,
    val source: String = "Static HTML",
    val mimeType: String = when {
        isStream -> "application/x-mpegURL"
        isVideo -> "video/mp4"
        isAudio -> "audio/mpeg"
        else -> "image/jpeg"
    },
    val resolutionHint: String? = null,
    val sizeBytes: Long? = null,
    val provenance: MediaProvenance = MediaProvenance(extractorEngine = source),
    val metadata: Map<String, String> = emptyMap(),
    val downloadHeaders: Map<String, String> = emptyMap(),
    val detectedAt: Long = System.currentTimeMillis()
)

data class ScrapeResult(
    val sourceUrl: String,
    val pageTitle: String,
    val domain: String,
    val items: List<ScrapedMediaItem>,
    val errorMessage: String? = null
)

