package com.amresalehin.emregallery.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.net.URL
import java.util.UUID

/**
 * High-speed static HTML / DOM extractor powered by OkHttp and Jsoup.
 * Reliably parses document metadata, OpenGraph tags, HTML5 video/audio/picture tags,
 * srcset, lazy-loaded attributes, CSS backgrounds, direct links, and iframes with shared session handling.
 */
class StaticMediaScraper {

    suspend fun scrape(inputUrl: String): StaticScrapeResult = withContext(Dispatchers.IO) {
        val trimmed = inputUrl.trim()
        if (trimmed.isBlank()) {
            return@withContext StaticScrapeResult("", "", "", emptyList(), "URL cannot be empty")
        }

        val normalizedUrl = if (!trimmed.startsWith("http://", ignoreCase = true) && !trimmed.startsWith("https://", ignoreCase = true)) {
            "https://$trimmed"
        } else {
            trimmed
        }

        val domain = runCatching { URL(normalizedUrl).host }.getOrDefault("")

        // Check if the input is a direct media file
        val isValid = MediaClassifier.isValidMedia(normalizedUrl)
        val classification = MediaClassifier.classify(normalizedUrl)
        val isDirectMedia = isValid && (classification.isVideo || classification.isAudio || classification.isStream ||
                normalizedUrl.endsWith(".jpg", true) || normalizedUrl.endsWith(".jpeg", true) ||
                normalizedUrl.endsWith(".png", true) || normalizedUrl.endsWith(".webp", true) ||
                normalizedUrl.endsWith(".gif", true) || normalizedUrl.endsWith(".svg", true))

        if (isDirectMedia) {
            val resolvedInfo = MediaClassifier.resolveOriginalMedia(normalizedUrl)
            val downloadUrl = resolvedInfo.mediaUrl
            val targetClass = MediaClassifier.classify(downloadUrl)
            val fileName = resolvedInfo.cleanTitle ?: MediaClassifier.deriveFileName(downloadUrl, targetClass.format, 0)
            val thumb = resolvedInfo.thumbnailUrl ?: if (targetClass.category == MediaCategory.IMAGES) downloadUrl else null
            val item = ScrapedMediaItem(
                id = "static_direct_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}",
                url = downloadUrl,
                title = fileName,
                isVideo = targetClass.isVideo,
                isAudio = targetClass.isAudio,
                isStream = targetClass.isStream,
                category = targetClass.category,
                format = targetClass.format,
                thumbnailUrl = thumb,
                mimeType = targetClass.mimeType,
                source = ExtractionSource.STATIC_HTML.label,
                provenance = MediaProvenance(
                    extractorEngine = "Direct URL",
                    pageUrl = normalizedUrl
                ),
                downloadHeaders = mapOf(
                    "User-Agent" to OkHttpDownloader.DEFAULT_USER_AGENT,
                    "Referer" to normalizedUrl
                )
            )
            return@withContext StaticScrapeResult(
                sourceUrl = normalizedUrl,
                pageTitle = fileName,
                domain = domain,
                items = listOf(item)
            )
        }

        try {
            val response = OkHttpDownloader.getHtml(normalizedUrl)
            if (!response.isSuccessful) {
                return@withContext StaticScrapeResult(
                    sourceUrl = normalizedUrl,
                    pageTitle = domain,
                    domain = domain,
                    items = emptyList(),
                    errorMessage = response.errorMessage ?: "Server returned HTTP status ${response.statusCode}"
                )
            }

            val contentType = response.contentType
            if (contentType.startsWith("image/") || contentType.startsWith("video/") ||
                contentType.startsWith("audio/") || contentType.contains("mpegurl") || contentType.contains("dash")
            ) {
                val directClass = MediaClassifier.classify(normalizedUrl, contentType)
                val fileName = MediaClassifier.deriveFileName(normalizedUrl, directClass.format, 0)
                val item = ScrapedMediaItem(
                    id = "static_direct_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}",
                    url = normalizedUrl,
                    title = fileName,
                    isVideo = directClass.isVideo,
                    isAudio = directClass.isAudio,
                    isStream = directClass.isStream,
                    category = directClass.category,
                    format = directClass.format,
                    mimeType = directClass.mimeType,
                    source = ExtractionSource.STATIC_HTML.label,
                    provenance = MediaProvenance(
                        extractorEngine = "Direct Response Header",
                        pageUrl = normalizedUrl
                    ),
                    downloadHeaders = mapOf(
                        "User-Agent" to OkHttpDownloader.DEFAULT_USER_AGENT,
                        "Referer" to normalizedUrl
                    )
                )
                return@withContext StaticScrapeResult(
                    sourceUrl = normalizedUrl,
                    pageTitle = fileName,
                    domain = domain,
                    items = listOf(item)
                )
            }

            val html = response.bodyString ?: ""
            val targetBaseUrl = response.finalUrl.ifBlank { normalizedUrl }
            val doc = Jsoup.parse(html, targetBaseUrl)
            val pageTitle = doc.title().trim().ifBlank { domain }
            val extractedItems = parseDocumentMedia(doc, targetBaseUrl)

            StaticScrapeResult(
                sourceUrl = normalizedUrl,
                pageTitle = pageTitle,
                domain = domain,
                items = extractedItems
            )
        } catch (e: Exception) {
            StaticScrapeResult(
                sourceUrl = normalizedUrl,
                pageTitle = domain,
                domain = domain,
                items = emptyList(),
                errorMessage = e.message ?: "Failed to scrape page"
            )
        }
    }

    fun parseDocumentMedia(doc: Document, baseUrl: String): List<ScrapedMediaItem> {
        val rawItems = mutableListOf<ScrapedMediaItem>()
        val processedElements = HashSet<org.jsoup.nodes.Element>()

        val sessionHeaders = mutableMapOf<String, String>().apply {
            put("Referer", baseUrl)
            put("User-Agent", OkHttpDownloader.DEFAULT_USER_AGENT)
            val sessionCookies = OkHttpDownloader.sharedCookieJar.getCookieString(baseUrl)
            if (sessionCookies.isNotBlank()) {
                put("Cookie", sessionCookies)
            }
        }

        fun emitResource(resource: DiscoveredMediaResource) {
            val built = MediaCaptureEngine.buildMediaItemFromResource(
                resource = resource,
                baseUrl = baseUrl,
                indexHint = rawItems.size
            ) ?: return
            val engineLabel = if (resource.source.label.startsWith("Static HTML", ignoreCase = true)) {
                resource.source.label
            } else {
                "Static HTML (${resource.source.label})"
            }
            rawItems.add(
                built.copy(
                    id = "static_${System.currentTimeMillis()}_${rawItems.size}",
                    provenance = built.provenance.copy(
                        extractorEngine = engineLabel,
                        pageUrl = baseUrl,
                        domSelector = resource.domSelector ?: built.provenance.domSelector
                    ),
                    downloadHeaders = built.downloadHeaders + sessionHeaders
                )
            )
        }

        fun isDirectMediaHref(rawHref: String): Boolean {
            if (rawHref.isBlank() || rawHref.startsWith("#") || rawHref.startsWith("javascript:", true)) return false
            val resolvedHref = MediaClassifier.resolveUrl(rawHref, baseUrl) ?: return false
            if (!MediaClassifier.isValidMedia(resolvedHref)) return false
            val cleanPath = resolvedHref.substringBefore("?").substringBefore("#").lowercase(java.util.Locale.ROOT)
            return MediaClassifier.KNOWN_MEDIA_EXTENSIONS.any { cleanPath.endsWith(".$it") }
        }

        fun scaleSrcsetDescriptor(res: String, url: String, w: Int?, h: Int?): String {
            val pxMatch = Regex("""[/_-](\d{2,5})px[-_./]""").find(url)
            return if (pxMatch != null) {
                "${pxMatch.groupValues[1]}px"
            } else if (res.isNotBlank() && res != "srcset") {
                if (res.endsWith("x", true) && w != null) {
                    val mult = res.removeSuffix("x").removeSuffix("X").toFloatOrNull() ?: 1f
                    val scaledW = (w * mult).toInt()
                    val scaledH = if (h != null) (h * mult).toInt() else null
                    if (scaledH != null) "${scaledW}x${scaledH}" else "${scaledW}w"
                } else {
                    res
                }
            } else if (w != null && h != null) {
                "${w}x${h}"
            } else if (w != null) {
                "${w}w"
            } else {
                "srcset"
            }
        }

        // 1. OpenGraph, Twitter Card & schema.org meta tags (paired video + image poster)
        val ogTitle = doc.selectFirst("meta[property=og:title], meta[name=twitter:title]")
            ?.let { it.attr("content").ifBlank { it.attr("value") }.trim() }
            ?.takeIf { it.isNotBlank() }

        val ogVideoUrls = LinkedHashSet<String>()
        for (sel in listOf(
            "meta[property=og:video:secure_url]",
            "meta[property=og:video:url]",
            "meta[property=og:video]",
            "meta[name=twitter:player:stream]",
            "meta[itemprop=video]"
        )) {
            for (meta in doc.select(sel)) {
                val content = meta.attr("content").ifBlank { meta.attr("value") }.trim()
                if (content.isNotBlank()) ogVideoUrls.add(content)
            }
        }
        val ogVideoType = doc.selectFirst("meta[property=og:video:type], meta[name=twitter:player:stream:content_type]")
            ?.attr("content")?.trim()?.takeIf { it.isNotBlank() }
        val ogVideoW = doc.selectFirst("meta[property=og:video:width], meta[name=twitter:player:width]")
            ?.attr("content")?.trim()?.toIntOrNull()
        val ogVideoH = doc.selectFirst("meta[property=og:video:height], meta[name=twitter:player:height]")
            ?.attr("content")?.trim()?.toIntOrNull()

        val ogAudioUrls = LinkedHashSet<String>()
        for (sel in listOf(
            "meta[property=og:audio:secure_url]",
            "meta[property=og:audio:url]",
            "meta[property=og:audio]",
            "meta[itemprop=audio]"
        )) {
            for (meta in doc.select(sel)) {
                val content = meta.attr("content").ifBlank { meta.attr("value") }.trim()
                if (content.isNotBlank()) ogAudioUrls.add(content)
            }
        }
        val ogAudioType = doc.selectFirst("meta[property=og:audio:type]")
            ?.attr("content")?.trim()?.takeIf { it.isNotBlank() }

        val ogImageUrls = LinkedHashSet<String>()
        for (sel in listOf(
            "meta[property=og:image:secure_url]",
            "meta[property=og:image:url]",
            "meta[property=og:image]",
            "meta[name=twitter:image]",
            "meta[name=twitter:image:src]",
            "meta[itemprop=image]"
        )) {
            for (meta in doc.select(sel)) {
                val content = meta.attr("content").ifBlank { meta.attr("value") }.trim()
                if (content.isNotBlank()) ogImageUrls.add(content)
            }
        }
        val ogImageW = doc.selectFirst("meta[property=og:image:width]")?.attr("content")?.trim()?.toIntOrNull()
        val ogImageH = doc.selectFirst("meta[property=og:image:height]")?.attr("content")?.trim()?.toIntOrNull()
        val ogImageAlt = doc.selectFirst("meta[property=og:image:alt], meta[name=twitter:image:alt]")
            ?.attr("content")?.trim()?.takeIf { it.isNotBlank() }

        val primaryOgImage = ogImageUrls.firstOrNull()
        val consumedOgImages = HashSet<String>()

        if (ogVideoUrls.isNotEmpty()) {
            val vRes = if (ogVideoW != null && ogVideoH != null) "${ogVideoW}x${ogVideoH}" else "OpenGraph"
            val variants = ogVideoUrls.map { u ->
                MediaVariantCandidate(
                    url = u,
                    descriptor = vRes,
                    width = ogVideoW,
                    height = ogVideoH,
                    mimeType = ogVideoType,
                    source = ExtractionSource.OPEN_GRAPH
                )
            }
            val companions = LinkedHashSet<String>().apply {
                addAll(ogVideoUrls)
                if (primaryOgImage != null) {
                    add(primaryOgImage)
                    consumedOgImages.add(primaryOgImage)
                }
            }
            emitResource(
                DiscoveredMediaResource(
                    primaryUrl = variants.first().url,
                    variants = variants,
                    mediaTypeHint = "video",
                    mimeHint = ogVideoType ?: "video/mp4",
                    titleHint = ogTitle,
                    thumbnailUrl = primaryOgImage,
                    companionUrls = companions.toList(),
                    width = ogVideoW,
                    height = ogVideoH,
                    resolutionHint = vRes,
                    source = ExtractionSource.OPEN_GRAPH,
                    domSelector = "meta[property=og:video]"
                )
            )
        }

        if (ogAudioUrls.isNotEmpty()) {
            val variants = ogAudioUrls.map { u ->
                MediaVariantCandidate(
                    url = u,
                    descriptor = "OpenGraph",
                    mimeType = ogAudioType,
                    source = ExtractionSource.OPEN_GRAPH
                )
            }
            val companions = LinkedHashSet<String>().apply {
                addAll(ogAudioUrls)
                if (primaryOgImage != null) {
                    add(primaryOgImage)
                    consumedOgImages.add(primaryOgImage)
                }
            }
            emitResource(
                DiscoveredMediaResource(
                    primaryUrl = variants.first().url,
                    variants = variants,
                    mediaTypeHint = "audio",
                    mimeHint = ogAudioType ?: "audio/mpeg",
                    titleHint = ogTitle,
                    thumbnailUrl = primaryOgImage,
                    companionUrls = companions.toList(),
                    source = ExtractionSource.OPEN_GRAPH,
                    domSelector = "meta[property=og:audio]"
                )
            )
        }

        for (imgUrl in ogImageUrls) {
            if (imgUrl in consumedOgImages) continue
            val iRes = if (ogImageW != null && ogImageH != null) "${ogImageW}x${ogImageH}" else "OpenGraph"
            emitResource(
                DiscoveredMediaResource(
                    primaryUrl = imgUrl,
                    variants = listOf(
                        MediaVariantCandidate(
                            url = imgUrl,
                            descriptor = iRes,
                            width = ogImageW,
                            height = ogImageH,
                            source = ExtractionSource.OPEN_GRAPH
                        )
                    ),
                    mediaTypeHint = "image",
                    titleHint = ogImageAlt ?: ogTitle,
                    thumbnailUrl = imgUrl,
                    companionUrls = listOf(imgUrl),
                    width = ogImageW,
                    height = ogImageH,
                    resolutionHint = iRes,
                    source = ExtractionSource.OPEN_GRAPH,
                    domSelector = "meta[property=og:image]"
                )
            )
        }

        // 2. JSON-LD (application/ld+json) recursive Schema.org extraction
        for (script in doc.select("script[type*=\"ld+json\"], script[type=\"application/ld+json\"]")) {
            val rawJson = script.data().ifBlank { script.html() }.trim()
            if (rawJson.isNotBlank()) {
                val jsonLdResources = MediaCaptureEngine.extractJsonLdResources(rawJson, baseUrl)
                for (res in jsonLdResources) {
                    emitResource(res)
                }
            }
        }

        val lazyAttributes = listOf(
            "data-src", "data-original", "data-lazy-src", "data-lazy",
            "data-full-url", "data-high-res-src", "data-hires", "data-large-file",
            "data-orig-file", "data-url", "data-actualsrc", "data-fallback-src"
        )

        // 3. <picture> elements (grouped <source> + child <img> + optional wrapping <a href>)
        for (picture in doc.select("picture")) {
            if (ContentAwareMediaFilter.isUiChromeElement(picture)) continue
            processedElements.add(picture)

            val variants = mutableListOf<MediaVariantCandidate>()
            val companionUrls = LinkedHashSet<String>()
            val childImg = picture.selectFirst("img")
            if (childImg != null) {
                processedElements.add(childImg)
                if (ContentAwareMediaFilter.isUiChromeElement(childImg)) continue
            }

            val w = childImg?.let { it.attr("width").toIntOrNull() ?: it.attr("data-width").toIntOrNull() }
            val h = childImg?.let { it.attr("height").toIntOrNull() ?: it.attr("data-height").toIntOrNull() }
            val figCaption = picture.closest("figure")?.selectFirst("figcaption")?.text()?.trim()?.takeIf { it.isNotBlank() }
            val titleHint = childImg?.attr("alt")?.trim()?.takeIf { it.isNotBlank() }
                ?: childImg?.attr("title")?.trim()?.takeIf { it.isNotBlank() }
                ?: figCaption

            val parentLink = picture.closest("a[href]")
            if (parentLink != null && !ContentAwareMediaFilter.isUiChromeElement(parentLink)) {
                val href = parentLink.attr("href").trim()
                if (isDirectMediaHref(href)) {
                    processedElements.add(parentLink)
                    variants.add(MediaVariantCandidate(url = href, descriptor = "Full Link"))
                    companionUrls.add(href)
                }
            }

            for (source in picture.select("source")) {
                processedElements.add(source)
                val mime = source.attr("type").trim().takeIf { it.isNotBlank() }
                val rawSrcset = source.attr("srcset").ifBlank { source.attr("data-srcset") }.trim()
                if (rawSrcset.isNotBlank()) {
                    for ((u, desc) in MediaClassifier.parseSrcset(rawSrcset, baseUrl)) {
                        val hint = scaleSrcsetDescriptor(desc, u, w, h)
                        variants.add(MediaVariantCandidate(url = u, descriptor = hint, width = w, height = h, mimeType = mime, source = ExtractionSource.SRCSET))
                        companionUrls.add(u)
                    }
                }
                val sSrc = source.attr("src").ifBlank { source.attr("data-src") }.trim()
                if (sSrc.isNotBlank() && !sSrc.startsWith("data:", true)) {
                    variants.add(MediaVariantCandidate(url = sSrc, width = w, height = h, mimeType = mime))
                    companionUrls.add(sSrc)
                }
            }

            var thumbCandidate: String? = null
            if (childImg != null) {
                for (attr in lazyAttributes) {
                    val v = childImg.attr(attr).trim()
                    if (v.isNotBlank() && !v.startsWith("data:", true) && !v.startsWith("about:", true)) {
                        val resHint = if (w != null && h != null) "${w}x${h}" else null
                        variants.add(MediaVariantCandidate(url = v, descriptor = resHint, width = w, height = h))
                        companionUrls.add(v)
                    }
                }
                val imgSrcset = childImg.attr("srcset").ifBlank { childImg.attr("data-srcset") }.trim()
                if (imgSrcset.isNotBlank()) {
                    for ((u, desc) in MediaClassifier.parseSrcset(imgSrcset, baseUrl)) {
                        val hint = scaleSrcsetDescriptor(desc, u, w, h)
                        variants.add(MediaVariantCandidate(url = u, descriptor = hint, width = w, height = h, source = ExtractionSource.SRCSET))
                        companionUrls.add(u)
                    }
                }
                val rawSrc = childImg.attr("src").trim()
                if (rawSrc.isNotBlank() && !rawSrc.startsWith("data:", true) && !rawSrc.startsWith("about:", true)) {
                    val resHint = if (w != null && h != null) "${w}x${h}" else null
                    variants.add(MediaVariantCandidate(url = rawSrc, descriptor = resHint, width = w, height = h))
                    companionUrls.add(rawSrc)
                    thumbCandidate = rawSrc
                }
            }

            if (variants.isNotEmpty()) {
                val resHint = if (w != null && h != null) "${w}x${h}" else variants.firstNotNullOfOrNull { it.descriptor }
                emitResource(
                    DiscoveredMediaResource(
                        primaryUrl = variants.first().url,
                        variants = variants,
                        mediaTypeHint = "image",
                        mimeHint = variants.firstNotNullOfOrNull { it.mimeType },
                        titleHint = titleHint,
                        thumbnailUrl = thumbCandidate ?: variants.last().url,
                        companionUrls = companionUrls.toList(),
                        width = w,
                        height = h,
                        resolutionHint = resHint,
                        source = ExtractionSource.DOM_SCRAPE,
                        domSelector = "picture"
                    )
                )
            }
        }

        // 4. <video> elements & posters (grouped with all <source> tags and fallback <img>)
        for (video in doc.select("video")) {
            processedElements.add(video)
            var poster = video.attr("poster")
                .ifBlank { video.attr("data-poster").ifBlank { video.attr("data-thumb") } }
                .trim()
                .takeIf { it.isNotBlank() && !it.startsWith("data:", true) }

            val fallbackImg = video.selectFirst("img")
            if (fallbackImg != null) {
                processedElements.add(fallbackImg)
                if (poster == null) {
                    poster = fallbackImg.attr("src").ifBlank { fallbackImg.attr("data-src") }.trim()
                        .takeIf { it.isNotBlank() && !it.startsWith("data:", true) }
                }
            }

            val vw = video.attr("width").toIntOrNull() ?: video.attr("data-width").toIntOrNull()
            val vh = video.attr("height").toIntOrNull() ?: video.attr("data-height").toIntOrNull()
            val vRes = if (vw != null && vh != null) "${vw}x${vh}" else null
            val vTitle = video.attr("title")
                .ifBlank { video.attr("aria-label").ifBlank { video.closest("figure")?.selectFirst("figcaption")?.text().orEmpty() } }
                .trim()
                .takeIf { it.isNotBlank() }

            val variants = mutableListOf<MediaVariantCandidate>()
            val companionUrls = LinkedHashSet<String>()
            if (poster != null) companionUrls.add(poster)

            for (attr in listOf("src", "data-src", "data-video", "data-mp4", "data-url")) {
                val rawSrc = video.attr(attr).trim()
                if (rawSrc.isNotBlank() && !rawSrc.startsWith("blob:", true) && !rawSrc.startsWith("data:", true)) {
                    variants.add(
                        MediaVariantCandidate(
                            url = rawSrc,
                            descriptor = vRes,
                            width = vw,
                            height = vh
                        )
                    )
                    companionUrls.add(rawSrc)
                }
            }

            for (source in video.select("source")) {
                processedElements.add(source)
                val sSrc = source.attr("src").ifBlank { source.attr("data-src") }.trim()
                if (sSrc.isNotBlank() && !sSrc.startsWith("blob:", true) && !sSrc.startsWith("data:", true)) {
                    val sType = source.attr("type").trim().takeIf { it.isNotBlank() }
                    val sResAttr = source.attr("res").ifBlank { source.attr("size").ifBlank { source.attr("label") } }.trim()
                    val sHeight = sResAttr.trimEnd('p', 'P').toIntOrNull()
                    val sHint = when {
                        sHeight != null -> "${sHeight}p"
                        vRes != null -> vRes
                        else -> null
                    }
                    variants.add(
                        MediaVariantCandidate(
                            url = sSrc,
                            descriptor = sHint,
                            width = vw,
                            height = sHeight ?: vh,
                            mimeType = sType
                        )
                    )
                    companionUrls.add(sSrc)
                }
            }

            if (variants.isNotEmpty()) {
                emitResource(
                    DiscoveredMediaResource(
                        primaryUrl = variants.first().url,
                        variants = variants,
                        mediaTypeHint = "video",
                        mimeHint = variants.firstNotNullOfOrNull { it.mimeType } ?: "video/mp4",
                        titleHint = vTitle,
                        thumbnailUrl = poster,
                        companionUrls = companionUrls.toList(),
                        width = vw,
                        height = vh,
                        resolutionHint = vRes ?: variants.firstNotNullOfOrNull { it.descriptor },
                        source = ExtractionSource.DOM_SCRAPE,
                        domSelector = "video"
                    )
                )
            } else if (!poster.isNullOrBlank()) {
                emitResource(
                    DiscoveredMediaResource(
                        primaryUrl = poster,
                        variants = listOf(MediaVariantCandidate(url = poster, descriptor = "Poster")),
                        mediaTypeHint = "image",
                        titleHint = vTitle,
                        thumbnailUrl = poster,
                        companionUrls = listOf(poster),
                        resolutionHint = "Poster",
                        source = ExtractionSource.DOM_SCRAPE,
                        domSelector = "video[poster]"
                    )
                )
            }
        }

        // 5. <audio> elements & audio sources
        for (audio in doc.select("audio")) {
            processedElements.add(audio)
            val artwork = audio.attr("poster")
                .ifBlank { audio.attr("data-thumb").ifBlank { audio.attr("data-cover") } }
                .trim()
                .takeIf { it.isNotBlank() && !it.startsWith("data:", true) }
            val aTitle = audio.attr("title")
                .ifBlank { audio.attr("aria-label").ifBlank { audio.closest("figure")?.selectFirst("figcaption")?.text().orEmpty() } }
                .trim()
                .takeIf { it.isNotBlank() }

            val variants = mutableListOf<MediaVariantCandidate>()
            val companionUrls = LinkedHashSet<String>()
            if (artwork != null) companionUrls.add(artwork)

            for (attr in listOf("src", "data-src", "data-audio", "data-url")) {
                val rawSrc = audio.attr(attr).trim()
                if (rawSrc.isNotBlank() && !rawSrc.startsWith("blob:", true) && !rawSrc.startsWith("data:", true)) {
                    variants.add(MediaVariantCandidate(url = rawSrc))
                    companionUrls.add(rawSrc)
                }
            }

            for (source in audio.select("source")) {
                processedElements.add(source)
                val sSrc = source.attr("src").ifBlank { source.attr("data-src") }.trim()
                if (sSrc.isNotBlank() && !sSrc.startsWith("blob:", true) && !sSrc.startsWith("data:", true)) {
                    val sType = source.attr("type").trim().takeIf { it.isNotBlank() }
                    variants.add(MediaVariantCandidate(url = sSrc, mimeType = sType))
                    companionUrls.add(sSrc)
                }
            }

            if (variants.isNotEmpty()) {
                emitResource(
                    DiscoveredMediaResource(
                        primaryUrl = variants.first().url,
                        variants = variants,
                        mediaTypeHint = "audio",
                        mimeHint = variants.firstNotNullOfOrNull { it.mimeType } ?: "audio/mpeg",
                        titleHint = aTitle,
                        thumbnailUrl = artwork,
                        companionUrls = companionUrls.toList(),
                        source = ExtractionSource.DOM_SCRAPE,
                        domSelector = "audio"
                    )
                )
            }
        }

        // 6. Video containers, cards, and articles with data-trailer / data-main-thumb / data-video attributes
        val containerSelectors = listOf(
            "[data-trailer]", "[data-main-thumb]", "[data-video]", "[data-mp4]", "[data-poster]"
        )
        for (sel in containerSelectors) {
            for (el in doc.select(sel)) {
                if (el in processedElements) continue
                if (el.tagName().equals("video", true) || el.tagName().equals("img", true) || el.tagName().equals("audio", true)) continue
                processedElements.add(el)

                val trailer = el.attr("data-trailer")
                    .ifBlank { el.attr("data-video").ifBlank { el.attr("data-mp4") } }
                    .trim()
                val thumb = el.attr("data-main-thumb")
                    .ifBlank { el.attr("data-thumb").ifBlank { el.attr("data-poster") } }
                    .trim()
                val title = el.attr("title")
                    .ifBlank { el.selectFirst("a[title]")?.attr("title") ?: el.selectFirst(".title, h2, h3, figcaption")?.text().orEmpty() }
                    .trim()
                    .takeIf { it.isNotBlank() }

                if (trailer.isNotBlank() && !trailer.startsWith("data:", true)) {
                    val validThumb = thumb.takeIf { it.isNotBlank() && !it.startsWith("data:", true) }
                    val companions = LinkedHashSet<String>().apply {
                        add(trailer)
                        if (validThumb != null) add(validThumb)
                    }
                    // Mark any child <img> that merely renders the container's poster thumbnail
                    for (childImg in el.select("img")) {
                        val cSrc = childImg.attr("src").ifBlank { childImg.attr("data-src") }.trim()
                        if (validThumb != null && (cSrc == validThumb || MediaClassifier.resolveUrl(cSrc, baseUrl) == MediaClassifier.resolveUrl(validThumb, baseUrl))) {
                            processedElements.add(childImg)
                        }
                    }
                    emitResource(
                        DiscoveredMediaResource(
                            primaryUrl = trailer,
                            variants = listOf(MediaVariantCandidate(url = trailer)),
                            mediaTypeHint = "video",
                            mimeHint = "video/mp4",
                            titleHint = title,
                            thumbnailUrl = validThumb,
                            companionUrls = companions.toList(),
                            source = ExtractionSource.DOM_SCRAPE,
                            domSelector = "$sel (container)"
                        )
                    )
                } else if (thumb.isNotBlank() && !thumb.startsWith("data:", true)) {
                    emitResource(
                        DiscoveredMediaResource(
                            primaryUrl = thumb,
                            variants = listOf(MediaVariantCandidate(url = thumb)),
                            mediaTypeHint = "image",
                            titleHint = title,
                            thumbnailUrl = thumb,
                            companionUrls = listOf(thumb),
                            source = ExtractionSource.DOM_SCRAPE,
                            domSelector = "$sel[thumb]"
                        )
                    )
                }
            }
        }

        // 7. Standalone <img> elements (grouped with wrapping <a href>, lazy attributes, srcset, and src)
        for (img in doc.select("img")) {
            if (img in processedElements) continue
            if (ContentAwareMediaFilter.isUiChromeElement(img)) continue
            processedElements.add(img)

            val w = img.attr("width").toIntOrNull() ?: img.attr("data-width").toIntOrNull()
            val h = img.attr("height").toIntOrNull() ?: img.attr("data-height").toIntOrNull()
            val resHint = if (w != null && h != null) "${w}x${h}" else if (w != null) "${w}w" else null
            val figCaption = img.closest("figure")?.selectFirst("figcaption")?.text()?.trim()?.takeIf { it.isNotBlank() }
            val alt = img.attr("alt").trim().takeIf { it.isNotBlank() }
                ?: img.attr("title").trim().takeIf { it.isNotBlank() }
                ?: img.attr("aria-label").trim().takeIf { it.isNotBlank() }
                ?: figCaption

            val variants = mutableListOf<MediaVariantCandidate>()
            val companionUrls = LinkedHashSet<String>()

            // Check if wrapped in a direct-media <a href>
            val parentLink = img.closest("a[href]")
            var parentLinkTitle: String? = null
            if (parentLink != null && !ContentAwareMediaFilter.isUiChromeElement(parentLink)) {
                val href = parentLink.attr("href").trim()
                if (isDirectMediaHref(href)) {
                    processedElements.add(parentLink)
                    variants.add(MediaVariantCandidate(url = href, descriptor = "Full Link"))
                    companionUrls.add(href)
                    parentLinkTitle = parentLink.attr("title").ifBlank { parentLink.text() }.trim().takeIf { it.isNotBlank() }
                }
            }

            // Lazy-load high-res attributes
            for (attr in lazyAttributes) {
                val v = img.attr(attr).trim()
                if (v.isNotBlank() && !v.startsWith("data:", true) && !v.startsWith("about:", true)) {
                    variants.add(MediaVariantCandidate(url = v, descriptor = resHint, width = w, height = h))
                    companionUrls.add(v)
                }
            }

            // Srcset / data-srcset on the same <img>
            val rawSrcset = img.attr("srcset").ifBlank { img.attr("data-srcset") }.trim()
            if (rawSrcset.isNotBlank()) {
                for ((u, desc) in MediaClassifier.parseSrcset(rawSrcset, baseUrl)) {
                    val hint = scaleSrcsetDescriptor(desc, u, w, h)
                    variants.add(MediaVariantCandidate(url = u, descriptor = hint, width = w, height = h, source = ExtractionSource.SRCSET))
                    companionUrls.add(u)
                }
            }

            val thumbAttr = img.attr("data-main-thumb")
                .ifBlank { img.attr("data-thumb").ifBlank { img.attr("data-poster") } }
                .trim()
                .takeIf { it.isNotBlank() && !it.startsWith("data:", true) && !it.startsWith("about:", true) }
            if (thumbAttr != null) {
                variants.add(MediaVariantCandidate(url = thumbAttr, descriptor = resHint, width = w, height = h))
                companionUrls.add(thumbAttr)
            }

            val rawSrc = img.attr("src").trim()
                .takeIf { it.isNotBlank() && !it.startsWith("data:", true) && !it.startsWith("about:", true) }
            if (rawSrc != null) {
                variants.add(MediaVariantCandidate(url = rawSrc, descriptor = resHint, width = w, height = h))
                companionUrls.add(rawSrc)
            }

            if (variants.isNotEmpty()) {
                val sourceType = if (rawSrcset.isNotBlank() && variants.size > 1 && parentLink == null) {
                    ExtractionSource.SRCSET
                } else {
                    ExtractionSource.DOM_SCRAPE
                }
                emitResource(
                    DiscoveredMediaResource(
                        primaryUrl = variants.first().url,
                        variants = variants,
                        mediaTypeHint = "image",
                        titleHint = alt ?: parentLinkTitle,
                        thumbnailUrl = rawSrc ?: thumbAttr ?: variants.last().url,
                        companionUrls = companionUrls.toList(),
                        width = w,
                        height = h,
                        resolutionHint = resHint ?: variants.firstNotNullOfOrNull { it.descriptor },
                        source = sourceType,
                        domSelector = "img"
                    )
                )
            }
        }

        // 8. Remaining [srcset], [data-srcset] elements not already grouped with <picture> or <img>
        for (elem in doc.select("[srcset], [data-srcset]")) {
            if (elem in processedElements) continue
            if (ContentAwareMediaFilter.isUiChromeElement(elem)) continue
            processedElements.add(elem)

            val rawSrcset = elem.attr("srcset").ifBlank { elem.attr("data-srcset") }.trim()
            val w = elem.attr("width").toIntOrNull() ?: elem.attr("data-width").toIntOrNull()
            val h = elem.attr("height").toIntOrNull() ?: elem.attr("data-height").toIntOrNull()
            val alt = elem.attr("alt").ifBlank { elem.attr("title") }.trim().takeIf { it.isNotBlank() }
            val mime = elem.attr("type").trim().takeIf { it.isNotBlank() }
            if (rawSrcset.isNotBlank()) {
                val entries = MediaClassifier.parseSrcset(rawSrcset, baseUrl)
                if (entries.isNotEmpty()) {
                    val variants = entries.map { (u, desc) ->
                        val hint = scaleSrcsetDescriptor(desc, u, w, h)
                        MediaVariantCandidate(url = u, descriptor = hint, width = w, height = h, mimeType = mime, source = ExtractionSource.SRCSET)
                    }
                    emitResource(
                        DiscoveredMediaResource(
                            primaryUrl = variants.last().url,
                            variants = variants,
                            mediaTypeHint = "image",
                            mimeHint = mime,
                            titleHint = alt,
                            thumbnailUrl = variants.first().url,
                            companionUrls = variants.map { it.url },
                            width = w,
                            height = h,
                            resolutionHint = variants.last().descriptor,
                            source = ExtractionSource.SRCSET,
                            domSelector = "[srcset]"
                        )
                    )
                }
            }
        }

        // 9. Content CSS background-image extraction (strictly excludes UI chrome, icons, buttons)
        for (styled in doc.select("[style*='url('], [style*='url(\"'], [style*='url(&quot;']")) {
            if (!ContentAwareMediaFilter.isAcceptableCssBackground(styled)) continue

            val style = styled.attr("style")
            val urlIndex = style.indexOf("url(", ignoreCase = true)
            if (urlIndex != -1) {
                val sub = style.substring(urlIndex + 4)
                val closeIndex = sub.indexOf(")")
                if (closeIndex != -1) {
                    val rawUrl = sub.substring(0, closeIndex)
                        .replace("\"", "")
                        .replace("'", "")
                        .replace("&quot;", "")
                        .trim()
                    if (rawUrl.isNotBlank() && !ContentAwareMediaFilter.isUiChromeUrl(rawUrl)) {
                        val bgTitle = styled.attr("title").ifBlank { styled.attr("aria-label") }.trim().takeIf { it.isNotBlank() }
                        emitResource(
                            DiscoveredMediaResource(
                                primaryUrl = rawUrl,
                                variants = listOf(MediaVariantCandidate(url = rawUrl, source = ExtractionSource.CSS_BACKGROUND)),
                                mediaTypeHint = "image",
                                titleHint = bgTitle,
                                thumbnailUrl = rawUrl,
                                companionUrls = listOf(rawUrl),
                                source = ExtractionSource.CSS_BACKGROUND,
                                domSelector = "style[background-image]"
                            )
                        )
                    }
                }
            }
        }

        // 10. iFrame inspection (only direct media files embedded in iframes, reject web pages)
        for (iframe in doc.select("iframe[src]")) {
            val src = iframe.attr("src").trim()
            if (src.isNotBlank() && !ContentAwareMediaFilter.isUiChromeElement(iframe)) {
                val cleanPath = src.substringBefore("?").substringBefore("#").lowercase(java.util.Locale.ROOT)
                val isDirectMediaFile = MediaClassifier.KNOWN_MEDIA_EXTENSIONS.any { cleanPath.endsWith(".$it") }
                if (isDirectMediaFile) {
                    emitResource(
                        DiscoveredMediaResource(
                            primaryUrl = src,
                            variants = listOf(MediaVariantCandidate(url = src, descriptor = "iFrame Media", source = ExtractionSource.IFRAME)),
                            resolutionHint = "iFrame Media",
                            source = ExtractionSource.IFRAME,
                            domSelector = "iframe"
                        )
                    )
                }
            }
        }

        // 11. Direct anchor links to media files (content elements not already paired with <picture> or <img>)
        for (link in doc.select("a[href]")) {
            if (link in processedElements) continue
            if (ContentAwareMediaFilter.isUiChromeElement(link)) continue

            val href = link.attr("href").trim()
            if (!isDirectMediaHref(href)) continue
            val resolvedHref = MediaClassifier.resolveUrl(href, baseUrl) ?: continue

            val childImg = link.selectFirst("img")
            val childThumb = childImg?.attr("src")?.ifBlank { childImg.attr("data-src") }?.trim()
            val poster = if (!childThumb.isNullOrBlank()) MediaClassifier.resolveUrl(childThumb, baseUrl) else null
            val linkTitle = link.attr("title")
                .ifBlank { childImg?.attr("alt").orEmpty().ifBlank { link.text() } }
                .trim()
                .takeIf { it.isNotBlank() }
            val companions = LinkedHashSet<String>().apply {
                add(resolvedHref)
                if (poster != null) add(poster)
            }
            emitResource(
                DiscoveredMediaResource(
                    primaryUrl = resolvedHref,
                    variants = listOf(MediaVariantCandidate(url = resolvedHref, descriptor = "Full Link")),
                    titleHint = linkTitle,
                    thumbnailUrl = poster,
                    companionUrls = companions.toList(),
                    resolutionHint = "Full Link",
                    source = ExtractionSource.DOM_SCRAPE,
                    domSelector = "a[href]"
                )
            )
        }

        return MediaClassifier.deduplicateScrapedItems(rawItems)
    }
}

data class StaticScrapeResult(
    val sourceUrl: String,
    val pageTitle: String,
    val domain: String,
    val items: List<ScrapedMediaItem>,
    val errorMessage: String? = null
)
