package com.amresalehin.emregallery.data

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.util.Locale

/**
 * Unified Media Capture Engine.
 * Single source of truth for structured media resource discovery:
 * 1. Network request interception & header/stream/media classification.
 * 2. Deep JavaScript structured DOM, <picture>, srcset, <video>/<audio> sources, OpenGraph, CSS background, and JSON-LD inspection.
 * 3. Recursive Schema.org JSON-LD graph & entity parser with thumbnail and metadata linking.
 * 4. MutationObserver injection for structured dynamic DOM change detection.
 * 5. Adaptive scrolling logic.
 * 6. Resource variant selection, companion thumbnail folding, and ScrapedMediaItem reconciliation.
 */
object MediaCaptureEngine {

    /**
     * Shared JavaScript DOM scan script that discovers structured media resources rather than flat URLs:
     * - <picture> (<source srcset/type> variants + child <img> preview/alt/dimensions)
     * - <a href="media"> wrapping <img> (high-res target + child <img> thumbnail relationship)
     * - <img> (srcset, data-src/data-original/data-full-url, currentSrc, src, naturalWidth/Height, alt/figcaption)
     * - <video> (src, all <source src/type/res> variants, poster, fallback <img>, videoWidth/Height, duration)
     * - <audio> (src, all <source src/type> variants, artwork thumbnail, duration)
     * - OpenGraph & Twitter Card meta tags (pairing og:video with og:image/twitter:image & og:title)
     * - Schema.org JSON-LD raw blocks for structured graph extraction
     * - Content container CSS background-image & direct media IFrames
     */
    fun getJsDomScanScript(): String {
        return """
            (function() {
                var list = [];
                var processedEls = new Set();

                function resolveAbs(u) {
                    if (!u || typeof u !== 'string') return null;
                    var trimmed = u.trim();
                    if (!trimmed || trimmed.indexOf('javascript:') === 0 || trimmed.indexOf('mailto:') === 0 || trimmed.indexOf('about:') === 0) return null;
                    if (trimmed.indexOf('data:') === 0) return trimmed.length >= 2048 ? trimmed : null;
                    if (trimmed.indexOf('blob:') === 0) return null;
                    try {
                        return new URL(trimmed, document.baseURI || window.location.href).href;
                    } catch(e) {
                        if (trimmed.indexOf('//') === 0) return 'https:' + trimmed;
                        return trimmed;
                    }
                }

                function isChromeElement(el) {
                    if (!el) return false;
                    var chromeParent = el.closest('header, nav, footer, aside, menu, form, [role="banner"], [role="navigation"], [role="contentinfo"], .header, .site-header, .nav, .navbar, .site-nav, .menu, #header, #nav, #navbar, #footer, #mw-navigation, #p-logo, .footer, .site-footer, .breadcrumb, .breadcrumbs, .pagination, .toolbar, .ad, .ads, .advertisement, .cookie, .cookie-banner, .consent');
                    if (chromeParent) {
                        var contentParent = el.closest('article, main, [role="main"], #content, #main-content, .mw-parser-output, figure, .gallery, .shots-grid, .shots, .dribbble-shot, .entry-content, .post-content');
                        if (!contentParent || chromeParent.contains(contentParent) === false) {
                            return true;
                        }
                    }
                    var idAndClass = ((el.id || '') + ' ' + (el.className || '') + ' ' + (el.getAttribute('alt') || '')).toLowerCase();
                    if (/logo|favicon|avatar_default|badge|donate|donation|fundraising|paypal|magnifying-glass|nav-icon|menu-icon|close-icon|arrow-|chevron|bullet|spinner|1x1/.test(idAndClass)) {
                        return true;
                    }
                    return false;
                }

                function parseSrcsetEntries(srcsetStr, mimeHint, sourceTag) {
                    var res = [];
                    if (!srcsetStr) return res;
                    var parts = srcsetStr.split(',');
                    for (var p = 0; p < parts.length; p++) {
                        var trimmed = parts[p].trim();
                        if (!trimmed) continue;
                        var splitBits = trimmed.split(/\s+/);
                        var absU = resolveAbs(splitBits[0]);
                        if (absU) {
                            var desc = splitBits[1] || '';
                            var wVal = null;
                            if (desc.toLowerCase().endsWith('w')) {
                                wVal = parseInt(desc.slice(0, -1), 10) || null;
                            }
                            res.push({u: absU, r: desc, w: wVal, m: mimeHint || null, s: sourceTag || 'SRCSET'});
                        }
                    }
                    return res;
                }

                function extractElementTitle(el) {
                    if (!el) return null;
                    var t = el.getAttribute('alt') || el.getAttribute('title') || el.getAttribute('aria-label') || el.getAttribute('data-title') || '';
                    t = t.trim();
                    if (t) return t;
                    var fig = el.closest('figure');
                    if (fig) {
                        var cap = fig.querySelector('figcaption');
                        if (cap && cap.innerText) {
                            var capText = cap.innerText.trim();
                            if (capText && capText.length <= 160) return capText;
                        }
                    }
                    var link = el.closest('a[title]');
                    if (link) {
                        var lt = (link.getAttribute('title') || '').trim();
                        if (lt) return lt;
                    }
                    return null;
                }

                function collectImgVariants(img, variants, companions) {
                    if (!img) return null;
                    var lazyAttrs = [
                        'data-full-url', 'data-original', 'data-high-res-src', 'data-hires',
                        'data-large-file', 'data-orig-file', 'data-zoom-image', 'data-hi-res-src',
                        'data-src', 'data-lazy-src', 'data-lazy', 'data-url', 'data-actualsrc'
                    ];
                    for (var la = 0; la < lazyAttrs.length; la++) {
                        var val = resolveAbs(img.getAttribute(lazyAttrs[la]));
                        if (val) {
                            variants.push({u: val, s: 'DOM'});
                            companions.push(val);
                        }
                    }
                    var srcset = img.getAttribute('srcset') || img.getAttribute('data-srcset');
                    if (srcset) {
                        var sEntries = parseSrcsetEntries(srcset, null, 'SRCSET');
                        for (var se = 0; se < sEntries.length; se++) {
                            variants.push(sEntries[se]);
                            companions.push(sEntries[se].u);
                        }
                    }
                    var curSrc = resolveAbs(img.currentSrc);
                    var rawSrc = resolveAbs(img.getAttribute('src') || img.src);
                    var thumbAttr = resolveAbs(img.getAttribute('data-thumb') || img.getAttribute('data-main-thumb'));
                    if (curSrc) {
                        variants.push({u: curSrc, s: 'DOM'});
                        companions.push(curSrc);
                    }
                    if (rawSrc && rawSrc !== curSrc) {
                        variants.push({u: rawSrc, s: 'DOM'});
                        companions.push(rawSrc);
                    }
                    return thumbAttr || rawSrc || curSrc;
                }

                // 1. Structured <picture> elements (group <source> variants + fallback <img>)
                var pictures = document.querySelectorAll('picture');
                for (var pi = 0; pi < pictures.length; pi++) {
                    var pic = pictures[pi];
                    if (isChromeElement(pic)) continue;
                    processedEls.add(pic);
                    var variants = [];
                    var companions = [];
                    var pSources = pic.querySelectorAll('source');
                    for (var psi = 0; psi < pSources.length; psi++) {
                        var ps = pSources[psi];
                        processedEls.add(ps);
                        var psMime = ps.getAttribute('type') || null;
                        var psSrcset = ps.getAttribute('srcset') || ps.getAttribute('data-srcset');
                        if (psSrcset) {
                            var entries = parseSrcsetEntries(psSrcset, psMime, 'SRCSET');
                            for (var eIdx = 0; eIdx < entries.length; eIdx++) {
                                variants.push(entries[eIdx]);
                                companions.push(entries[eIdx].u);
                            }
                        }
                        var psSrc = resolveAbs(ps.getAttribute('src') || ps.src);
                        if (psSrc) {
                            variants.push({u: psSrc, m: psMime, s: 'DOM'});
                            companions.push(psSrc);
                        }
                    }
                    var childImg = pic.querySelector('img');
                    var previewUrl = null;
                    var w = null, h = null, title = null;
                    if (childImg) {
                        processedEls.add(childImg);
                        previewUrl = collectImgVariants(childImg, variants, companions);
                        w = (childImg.naturalWidth > 0 ? childImg.naturalWidth : null) || parseInt(childImg.getAttribute('width') || childImg.getAttribute('data-width') || '0', 10) || null;
                        h = (childImg.naturalHeight > 0 ? childImg.naturalHeight : null) || parseInt(childImg.getAttribute('height') || childImg.getAttribute('data-height') || '0', 10) || null;
                        title = extractElementTitle(childImg);
                    }
                    var parentLink = pic.closest('a[href]');
                    if (parentLink && !isChromeElement(parentLink)) {
                        var hrefAbs = resolveAbs(parentLink.getAttribute('href'));
                        if (hrefAbs && /\.(?:jpe?g|png|webp|gif|avif|mp4|webm|mkv|mov)(?:[?#]|$)/i.test(hrefAbs)) {
                            processedEls.add(parentLink);
                            variants.unshift({u: hrefAbs, r: 'Full Link', s: 'DOM'});
                            companions.push(hrefAbs);
                        }
                    }
                    if (variants.length > 0) {
                        list.push({
                            u: variants[0].u,
                            s: variants[0].s || 'SRCSET',
                            t: 'image',
                            p: previewUrl,
                            w: w,
                            h: h,
                            title: title,
                            sel: 'picture',
                            variants: variants,
                            c: companions
                        });
                    }
                }

                // 2. Standalone <img> elements (grouped with parent media <a> and srcset/data-* variants)
                var imgs = document.querySelectorAll('img');
                for (var i = 0; i < imgs.length; i++) {
                    var img = imgs[i];
                    if (processedEls.has(img) || isChromeElement(img)) continue;
                    // Skip fallback <img> inside <video>
                    if (img.closest('video')) {
                        processedEls.add(img);
                        continue;
                    }
                    processedEls.add(img);
                    var variants = [];
                    var companions = [];
                    var parentLink = img.closest('a[href]');
                    if (parentLink && !isChromeElement(parentLink)) {
                        var linkHref = resolveAbs(parentLink.getAttribute('href'));
                        if (linkHref && /\.(?:jpe?g|png|webp|gif|avif|mp4|webm|mkv|mov)(?:[?#]|$)/i.test(linkHref)) {
                            processedEls.add(parentLink);
                            variants.push({u: linkHref, r: 'Full Link', s: 'DOM'});
                            companions.push(linkHref);
                        }
                    }
                    var previewUrl = collectImgVariants(img, variants, companions);
                    var w = (img.naturalWidth > 0 ? img.naturalWidth : null) || parseInt(img.getAttribute('width') || img.getAttribute('data-width') || '0', 10) || null;
                    var h = (img.naturalHeight > 0 ? img.naturalHeight : null) || parseInt(img.getAttribute('height') || img.getAttribute('data-height') || '0', 10) || null;
                    var title = extractElementTitle(img);
                    if (variants.length > 0) {
                        list.push({
                            u: variants[0].u,
                            s: variants[0].s || 'DOM',
                            t: 'image',
                            p: previewUrl,
                            w: w,
                            h: h,
                            title: title,
                            sel: 'img',
                            variants: variants,
                            c: companions
                        });
                    }
                }

                // 3. Remaining standalone <source> not inside <picture>, <video>, or <audio>
                var looseSources = document.querySelectorAll('source');
                for (var ls = 0; ls < looseSources.length; ls++) {
                    var srcEl = looseSources[ls];
                    if (processedEls.has(srcEl) || srcEl.closest('picture, video, audio')) continue;
                    processedEls.add(srcEl);
                    var lsSet = srcEl.getAttribute('srcset') || srcEl.getAttribute('data-srcset');
                    var lsMime = srcEl.getAttribute('type') || null;
                    var lsVariants = parseSrcsetEntries(lsSet, lsMime, 'SRCSET');
                    if (lsVariants.length > 0) {
                        list.push({
                            u: lsVariants[0].u,
                            s: 'SRCSET',
                            m: lsMime,
                            sel: 'source',
                            variants: lsVariants
                        });
                    }
                }

                // 4. Structured <video> elements (all <source> tags, poster, fallback <img>, dimensions, duration)
                var videos = document.querySelectorAll('video');
                for (var v = 0; v < videos.length; v++) {
                    var vid = videos[v];
                    processedEls.add(vid);
                    var poster = resolveAbs(vid.getAttribute('poster') || vid.poster || vid.getAttribute('data-poster') || vid.getAttribute('data-thumb'));
                    if (!poster) {
                        var fallbackImg = vid.querySelector('img');
                        if (fallbackImg) {
                            poster = resolveAbs(fallbackImg.getAttribute('src') || fallbackImg.src);
                        }
                    }
                    var vVariants = [];
                    var vCompanions = [];
                    if (poster) vCompanions.push(poster);

                    var vDirectAttrs = [vid.currentSrc, vid.getAttribute('src') || vid.src, vid.getAttribute('data-src'), vid.getAttribute('data-video'), vid.getAttribute('data-mp4')];
                    for (var vda = 0; vda < vDirectAttrs.length; vda++) {
                        var absV = resolveAbs(vDirectAttrs[vda]);
                        if (absV) {
                            vVariants.push({u: absV, s: 'DOM'});
                            vCompanions.push(absV);
                        }
                    }
                    var vsources = vid.querySelectorAll('source');
                    var primaryMime = null;
                    for (var j = 0; j < vsources.length; j++) {
                        var vsEl = vsources[j];
                        processedEls.add(vsEl);
                        var vsUrl = resolveAbs(vsEl.getAttribute('src') || vsEl.src || vsEl.getAttribute('data-src'));
                        var vsMime = vsEl.getAttribute('type') || null;
                        var vsRes = vsEl.getAttribute('res') || vsEl.getAttribute('size') || vsEl.getAttribute('label') || vsEl.getAttribute('data-res') || vsEl.getAttribute('data-quality') || null;
                        if (vsUrl) {
                            if (!primaryMime && vsMime) primaryMime = vsMime;
                            vVariants.push({u: vsUrl, r: vsRes, m: vsMime, s: 'DOM'});
                            vCompanions.push(vsUrl);
                        }
                    }
                    var vw = (vid.videoWidth > 0 ? vid.videoWidth : null) || parseInt(vid.getAttribute('width') || '0', 10) || null;
                    var vh = (vid.videoHeight > 0 ? vid.videoHeight : null) || parseInt(vid.getAttribute('height') || '0', 10) || null;
                    var vDur = (vid.duration && isFinite(vid.duration) && vid.duration > 0) ? Math.round(vid.duration) : null;
                    var vTitle = extractElementTitle(vid);

                    if (vVariants.length > 0) {
                        list.push({
                            u: vVariants[0].u,
                            s: 'DOM',
                            t: 'video',
                            m: primaryMime || 'video/mp4',
                            p: poster,
                            w: vw,
                            h: vh,
                            d: vDur,
                            title: vTitle,
                            sel: 'video',
                            variants: vVariants,
                            c: vCompanions
                        });
                    } else if (poster) {
                        list.push({
                            u: poster,
                            s: 'DOM',
                            t: 'image',
                            w: vw,
                            h: vh,
                            title: vTitle,
                            sel: 'video[poster]'
                        });
                    }
                }

                // 5. Structured <audio> elements
                var audios = document.querySelectorAll('audio');
                for (var a = 0; a < audios.length; a++) {
                    var au = audios[a];
                    processedEls.add(au);
                    var aVariants = [];
                    var aCompanions = [];
                    var aDirect = [au.currentSrc, au.getAttribute('src') || au.src, au.getAttribute('data-src')];
                    for (var ada = 0; ada < aDirect.length; ada++) {
                        var absA = resolveAbs(aDirect[ada]);
                        if (absA) {
                            aVariants.push({u: absA, s: 'DOM'});
                            aCompanions.push(absA);
                        }
                    }
                    var asources = au.querySelectorAll('source');
                    var aMime = null;
                    for (var k = 0; k < asources.length; k++) {
                        var asEl = asources[k];
                        processedEls.add(asEl);
                        var asUrl = resolveAbs(asEl.getAttribute('src') || asEl.src || asEl.getAttribute('data-src'));
                        var curAMime = asEl.getAttribute('type') || null;
                        if (asUrl) {
                            if (!aMime && curAMime) aMime = curAMime;
                            aVariants.push({u: asUrl, m: curAMime, s: 'DOM'});
                            aCompanions.push(asUrl);
                        }
                    }
                    var aThumb = resolveAbs(au.getAttribute('data-thumb') || au.getAttribute('data-cover') || au.getAttribute('data-artwork') || au.getAttribute('poster'));
                    var aDur = (au.duration && isFinite(au.duration) && au.duration > 0) ? Math.round(au.duration) : null;
                    var aTitle = extractElementTitle(au);
                    if (aVariants.length > 0) {
                        list.push({
                            u: aVariants[0].u,
                            s: 'DOM',
                            t: 'audio',
                            m: aMime || 'audio/mpeg',
                            p: aThumb,
                            d: aDur,
                            title: aTitle,
                            sel: 'audio',
                            variants: aVariants,
                            c: aCompanions
                        });
                    }
                }

                // 6. Data-attribute video cards/containers ([data-trailer], [data-video], [data-mp4])
                var vContainers = document.querySelectorAll('[data-trailer], [data-video], [data-mp4]');
                for (var vc = 0; vc < vContainers.length; vc++) {
                    var vcEl = vContainers[vc];
                    if (processedEls.has(vcEl)) continue;
                    var vcVideo = resolveAbs(vcEl.getAttribute('data-trailer') || vcEl.getAttribute('data-video') || vcEl.getAttribute('data-mp4'));
                    var vcThumb = resolveAbs(vcEl.getAttribute('data-main-thumb') || vcEl.getAttribute('data-thumb') || vcEl.getAttribute('data-poster'));
                    if (!vcThumb) {
                        var vcImg = vcEl.querySelector('img');
                        if (vcImg) vcThumb = resolveAbs(vcImg.currentSrc || vcImg.getAttribute('src') || vcImg.getAttribute('data-src'));
                    }
                    var vcTitle = extractElementTitle(vcEl);
                    if (vcVideo) {
                        list.push({
                            u: vcVideo,
                            s: 'DOM',
                            t: 'video',
                            m: 'video/mp4',
                            p: vcThumb,
                            title: vcTitle,
                            sel: '[data-video]',
                            c: vcThumb ? [vcThumb] : []
                        });
                    }
                }

                // 7. OpenGraph & Twitter Card structured meta discovery
                var ogVideo = resolveAbs((document.querySelector('meta[property="og:video:secure_url"], meta[property="og:video:url"], meta[property="og:video"], meta[name="twitter:player:stream"], meta[itemprop="video"]') || {}).content);
                var ogVideoType = (document.querySelector('meta[property="og:video:type"], meta[name="twitter:player:stream:content_type"]') || {}).content || null;
                var ogVideoW = parseInt(((document.querySelector('meta[property="og:video:width"]') || {}).content || '0'), 10) || null;
                var ogVideoH = parseInt(((document.querySelector('meta[property="og:video:height"]') || {}).content || '0'), 10) || null;
                var ogImage = resolveAbs((document.querySelector('meta[property="og:image:secure_url"], meta[property="og:image:url"], meta[property="og:image"], meta[name="twitter:image"], meta[itemprop="image"]') || {}).content);
                var ogImageW = parseInt(((document.querySelector('meta[property="og:image:width"]') || {}).content || '0'), 10) || null;
                var ogImageH = parseInt(((document.querySelector('meta[property="og:image:height"]') || {}).content || '0'), 10) || null;
                var ogAudio = resolveAbs((document.querySelector('meta[property="og:audio:secure_url"], meta[property="og:audio"], meta[itemprop="audio"]') || {}).content);
                var ogAudioType = (document.querySelector('meta[property="og:audio:type"]') || {}).content || null;
                var ogTitle = ((document.querySelector('meta[property="og:title"], meta[name="twitter:title"]') || {}).content || document.title || '').trim() || null;

                if (ogVideo) {
                    list.push({
                        u: ogVideo,
                        s: 'OPEN_GRAPH',
                        t: 'video',
                        m: ogVideoType || 'video/mp4',
                        p: ogImage,
                        w: ogVideoW,
                        h: ogVideoH,
                        title: ogTitle,
                        sel: 'meta[property=og:video]',
                        c: ogImage ? [ogImage] : []
                    });
                } else if (ogImage) {
                    list.push({
                        u: ogImage,
                        s: 'OPEN_GRAPH',
                        t: 'image',
                        w: ogImageW,
                        h: ogImageH,
                        title: ogTitle,
                        sel: 'meta[property=og:image]'
                    });
                }
                if (ogAudio) {
                    list.push({
                        u: ogAudio,
                        s: 'OPEN_GRAPH',
                        t: 'audio',
                        m: ogAudioType || 'audio/mpeg',
                        p: ogImage,
                        title: ogTitle,
                        sel: 'meta[property=og:audio]'
                    });
                }

                // 8. Schema.org JSON-LD blocks (passed as raw JSON-LD payloads for full recursive graph extraction in Kotlin)
                var jsonLdScripts = document.querySelectorAll('script[type="application/ld+json"]');
                for (var jl = 0; jl < jsonLdScripts.length; jl++) {
                    var rawLd = (jsonLdScripts[jl].innerText || jsonLdScripts[jl].textContent || '').trim();
                    if (rawLd) {
                        list.push({s: 'JSON_LD_RAW', jsonLd: rawLd});
                    }
                }

                // 9. Content container CSS background-image
                var bgElements = document.querySelectorAll('main, article, figure, [role="main"], #content, .gallery, .shots-grid, .shots, .photo, .hero');
                var count = Math.min(bgElements.length, 60);
                for (var b = 0; b < count; b++) {
                    var bEl = bgElements[b];
                    if (bEl.clientWidth >= 120 && bEl.clientHeight >= 120 && !isChromeElement(bEl)) {
                        var style = window.getComputedStyle(bEl);
                        var bg = style.backgroundImage;
                        if (bg && bg.indexOf('url(') !== -1) {
                            var match = bg.match(/url\(['"]?(.*?)['"]?\)/);
                            if (match && match[1] && !match[1].startsWith('data:')) {
                                var bgu = resolveAbs(match[1]);
                                if (bgu) {
                                    list.push({
                                        u: bgu,
                                        s: 'CSS',
                                        t: 'image',
                                        w: bEl.clientWidth || null,
                                        h: bEl.clientHeight || null,
                                        title: extractElementTitle(bEl),
                                        sel: 'style[background-image]'
                                    });
                                }
                            }
                        }
                    }
                }

                // 10. Direct anchor links to media files not already paired with an <img>
                var links = document.querySelectorAll('a[href]');
                for (var l = 0; l < links.length; l++) {
                    var aEl = links[l];
                    if (processedEls.has(aEl) || isChromeElement(aEl)) continue;
                    var aHref = resolveAbs(aEl.getAttribute('href'));
                    if (aHref && /\.(?:mp4|webm|mkv|mov|mp3|m4a|wav|flac|ogg|opus|jpe?g|png|webp|gif|avif)(?:[?#]|$)/i.test(aHref)) {
                        var aImg = aEl.querySelector('img');
                        var aThumb = aImg ? resolveAbs(aImg.currentSrc || aImg.getAttribute('src') || aImg.getAttribute('data-src')) : null;
                        var aText = (aEl.getAttribute('title') || aEl.innerText || '').trim();
                        list.push({
                            u: aHref,
                            s: 'DOM',
                            p: aThumb,
                            title: aText.length <= 120 ? aText : null,
                            sel: 'a[href]',
                            c: aThumb ? [aThumb] : []
                        });
                    }
                }

                // 11. Direct media IFrames
                var iframes = document.querySelectorAll('iframe');
                for (var f = 0; f < iframes.length; f++) {
                    var ifr = resolveAbs(iframes[f].src);
                    if (ifr && /\.(?:mp4|webm|mkv|mov|mp3|m4a|wav|jpe?g|png|webp|gif|avif)(?:[?#]|$)/i.test(ifr)) {
                        list.push({u: ifr, s: 'IFRAME', sel: 'iframe'});
                    }
                }

                return JSON.stringify(list);
            })();
        """.trimIndent()
    }

    /**
     * Shared JavaScript MutationObserver injection for structured dynamic DOM additions.
     * Reports structured resource metadata (variants, poster relationship, dimensions, MIME type, title)
     * via `EmreBridge.reportResource(json)` with fallback to `EmreBridge.reportMedia(url)`.
     */
    fun getMutationObserverScript(): String {
        return """
            (function() {
                if (window.__emreObserverInstalled) return;
                window.__emreObserverInstalled = true;

                function resolveAbs(u) {
                    if (!u || typeof u !== 'string') return null;
                    var trimmed = u.trim();
                    if (!trimmed || trimmed.indexOf('data:') === 0 || trimmed.indexOf('blob:') === 0 || trimmed.indexOf('javascript:') === 0 || trimmed.indexOf('about:') === 0) return null;
                    try {
                        return new URL(trimmed, document.baseURI || window.location.href).href;
                    } catch(e) {
                        return null;
                    }
                }

                function emitResource(resObj) {
                    if (!resObj || (!resObj.u && !resObj.jsonLd)) return;
                    try {
                        if (window.EmreBridge && window.EmreBridge.reportResource) {
                            window.EmreBridge.reportResource(JSON.stringify(resObj));
                        } else if (resObj.u && window.EmreBridge && window.EmreBridge.reportMedia) {
                            window.EmreBridge.reportMedia(resObj.u);
                        }
                    } catch(e) {}
                }

                function parseSrcsetList(srcsetStr, mimeHint) {
                    var out = [];
                    if (!srcsetStr) return out;
                    var parts = srcsetStr.split(',');
                    for (var i = 0; i < parts.length; i++) {
                        var bits = parts[i].trim().split(/\s+/);
                        var abs = resolveAbs(bits[0]);
                        if (abs) {
                            var desc = bits[1] || '';
                            var wVal = desc.toLowerCase().endsWith('w') ? (parseInt(desc.slice(0, -1), 10) || null) : null;
                            out.push({u: abs, r: desc, w: wVal, m: mimeHint || null, s: 'SRCSET'});
                        }
                    }
                    return out;
                }

                function checkNode(node) {
                    if (!node || node.nodeType !== 1) return;
                    var tag = node.tagName ? node.tagName.toUpperCase() : '';

                    if (tag === 'SOURCE') {
                        var parent = node.parentElement;
                        if (parent) {
                            checkNode(parent);
                            return;
                        }
                    }

                    if (tag === 'PICTURE') {
                        var pVariants = [];
                        var pCompanions = [];
                        var pSources = node.querySelectorAll ? node.querySelectorAll('source') : [];
                        for (var ps = 0; ps < pSources.length; ps++) {
                            var sMime = pSources[ps].getAttribute('type') || null;
                            var sSet = pSources[ps].getAttribute('srcset') || pSources[ps].getAttribute('data-srcset');
                            var parsed = parseSrcsetList(sSet, sMime);
                            for (var k = 0; k < parsed.length; k++) {
                                pVariants.push(parsed[k]);
                                pCompanions.push(parsed[k].u);
                            }
                        }
                        var pImg = node.querySelector ? node.querySelector('img') : null;
                        var pThumb = null;
                        var pw = null, ph = null, pTitle = null;
                        if (pImg) {
                            pThumb = resolveAbs(pImg.getAttribute('src') || pImg.src || pImg.currentSrc);
                            if (pThumb) {
                                pVariants.push({u: pThumb, s: 'DOM'});
                                pCompanions.push(pThumb);
                            }
                            pw = (pImg.naturalWidth > 0 ? pImg.naturalWidth : null) || parseInt(pImg.getAttribute('width') || '0', 10) || null;
                            ph = (pImg.naturalHeight > 0 ? pImg.naturalHeight : null) || parseInt(pImg.getAttribute('height') || '0', 10) || null;
                            pTitle = (pImg.getAttribute('alt') || pImg.getAttribute('title') || '').trim() || null;
                        }
                        if (pVariants.length > 0) {
                            emitResource({
                                u: pVariants[0].u,
                                s: pVariants[0].s || 'SRCSET',
                                t: 'image',
                                p: pThumb,
                                w: pw,
                                h: ph,
                                title: pTitle,
                                sel: 'picture',
                                variants: pVariants,
                                c: pCompanions
                            });
                        }
                        return;
                    }

                    if (tag === 'IMG') {
                        if (node.closest && node.closest('picture')) {
                            checkNode(node.closest('picture'));
                            return;
                        }
                        if (node.closest && node.closest('video')) return;
                        var variants = [];
                        var companions = [];
                        var attrs = ['data-full-url', 'data-original', 'data-high-res-src', 'data-large-file', 'data-hi-res-src', 'data-src', 'data-lazy-src'];
                        for (var a = 0; a < attrs.length; a++) {
                            var av = resolveAbs(node.getAttribute(attrs[a]));
                            if (av) {
                                variants.push({u: av, s: 'DOM'});
                                companions.push(av);
                            }
                        }
                        var srcset = node.getAttribute('srcset') || node.getAttribute('data-srcset');
                        var sList = parseSrcsetList(srcset, null);
                        for (var sl = 0; sl < sList.length; sl++) {
                            variants.push(sList[sl]);
                            companions.push(sList[sl].u);
                        }
                        var cur = resolveAbs(node.currentSrc);
                        var raw = resolveAbs(node.getAttribute('src') || node.src);
                        if (cur) { variants.push({u: cur, s: 'DOM'}); companions.push(cur); }
                        if (raw && raw !== cur) { variants.push({u: raw, s: 'DOM'}); companions.push(raw); }
                        if (variants.length > 0) {
                            var w = (node.naturalWidth > 0 ? node.naturalWidth : null) || parseInt(node.getAttribute('width') || '0', 10) || null;
                            var h = (node.naturalHeight > 0 ? node.naturalHeight : null) || parseInt(node.getAttribute('height') || '0', 10) || null;
                            var title = (node.getAttribute('alt') || node.getAttribute('title') || '').trim() || null;
                            emitResource({
                                u: variants[0].u,
                                s: variants[0].s || 'DOM',
                                t: 'image',
                                p: raw || cur,
                                w: w,
                                h: h,
                                title: title,
                                sel: 'img',
                                variants: variants,
                                c: companions
                            });
                        }
                    } else if (tag === 'VIDEO') {
                        var poster = resolveAbs(node.getAttribute('poster') || node.poster || node.getAttribute('data-poster'));
                        var vVariants = [];
                        var vCompanions = [];
                        if (poster) vCompanions.push(poster);
                        var vSrc = resolveAbs(node.currentSrc || node.getAttribute('src') || node.src || node.getAttribute('data-src'));
                        if (vSrc) {
                            vVariants.push({u: vSrc, s: 'DOM'});
                            vCompanions.push(vSrc);
                        }
                        var vMime = null;
                        if (node.querySelectorAll) {
                            var vSources = node.querySelectorAll('source');
                            for (var vs = 0; vs < vSources.length; vs++) {
                                var vsUrl = resolveAbs(vSources[vs].getAttribute('src') || vSources[vs].src);
                                var vsType = vSources[vs].getAttribute('type') || null;
                                var vsRes = vSources[vs].getAttribute('res') || vSources[vs].getAttribute('size') || vSources[vs].getAttribute('label') || null;
                                if (vsUrl) {
                                    if (!vMime && vsType) vMime = vsType;
                                    vVariants.push({u: vsUrl, r: vsRes, m: vsType, s: 'DOM'});
                                    vCompanions.push(vsUrl);
                                }
                            }
                        }
                        var vw = (node.videoWidth > 0 ? node.videoWidth : null) || parseInt(node.getAttribute('width') || '0', 10) || null;
                        var vh = (node.videoHeight > 0 ? node.videoHeight : null) || parseInt(node.getAttribute('height') || '0', 10) || null;
                        var vTitle = (node.getAttribute('title') || node.getAttribute('aria-label') || '').trim() || null;
                        if (vVariants.length > 0) {
                            emitResource({
                                u: vVariants[0].u,
                                s: 'DOM',
                                t: 'video',
                                m: vMime || 'video/mp4',
                                p: poster,
                                w: vw,
                                h: vh,
                                title: vTitle,
                                sel: 'video',
                                variants: vVariants,
                                c: vCompanions
                            });
                        } else if (poster) {
                            emitResource({
                                u: poster,
                                s: 'DOM',
                                t: 'image',
                                w: vw,
                                h: vh,
                                title: vTitle,
                                sel: 'video[poster]'
                            });
                        }
                    } else if (tag === 'AUDIO') {
                        var aVariants = [];
                        var aSrc = resolveAbs(node.currentSrc || node.getAttribute('src') || node.src || node.getAttribute('data-src'));
                        if (aSrc) aVariants.push({u: aSrc, s: 'DOM'});
                        var aMime = null;
                        if (node.querySelectorAll) {
                            var aSources = node.querySelectorAll('source');
                            for (var as = 0; as < aSources.length; as++) {
                                var asUrl = resolveAbs(aSources[as].getAttribute('src') || aSources[as].src);
                                var asType = aSources[as].getAttribute('type') || null;
                                if (asUrl) {
                                    if (!aMime && asType) aMime = asType;
                                    aVariants.push({u: asUrl, m: asType, s: 'DOM'});
                                }
                            }
                        }
                        if (aVariants.length > 0) {
                            emitResource({
                                u: aVariants[0].u,
                                s: 'DOM',
                                t: 'audio',
                                m: aMime || 'audio/mpeg',
                                sel: 'audio',
                                variants: aVariants
                            });
                        }
                    } else if (tag === 'SCRIPT' && (node.getAttribute('type') || '').toLowerCase() === 'application/ld+json') {
                        var ldText = (node.innerText || node.textContent || '').trim();
                        if (ldText) {
                            emitResource({s: 'JSON_LD_RAW', jsonLd: ldText});
                        }
                    }

                    if (node.querySelectorAll) {
                        var children = node.querySelectorAll('picture, img, video, audio, script[type="application/ld+json"]');
                        for (var c = 0; c < children.length; c++) {
                            checkNode(children[c]);
                        }
                    }
                }

                var observer = new MutationObserver(function(mutations) {
                    for (var m = 0; m < mutations.length; m++) {
                        var mut = mutations[m];
                        if (mut.type === 'childList') {
                            for (var i = 0; i < mut.addedNodes.length; i++) {
                                checkNode(mut.addedNodes[i]);
                            }
                        } else if (mut.type === 'attributes') {
                            checkNode(mut.target);
                        }
                    }
                });

                observer.observe(document.body || document.documentElement, {
                    childList: true,
                    subtree: true,
                    attributes: true,
                    attributeFilter: ['src', 'data-src', 'data-original', 'data-lazy-src', 'data-full-url', 'srcset', 'data-srcset', 'poster', 'data-video', 'data-trailer']
                });
            })();
        """.trimIndent()
    }

    /**
     * Shared JavaScript adaptive scrolling script using `behavior: 'instant'` to avoid
     * 500ms smooth-scroll animation overhead during automated background scraping.
     */
    fun getAdaptiveScrollScript(): String {
        return """
            (function() {
                var doc = document.documentElement || document.body;
                var scrollY = Math.round(window.pageYOffset || doc.scrollTop || 0);
                var innerHeight = window.innerHeight || 0;
                var scrollHeight = doc.scrollHeight || 0;
                var remaining = scrollHeight - (scrollY + innerHeight);

                var scrollDelta = Math.max(innerHeight * 0.85, 400);
                window.scrollBy({ top: scrollDelta, behavior: 'instant' });
                window.dispatchEvent(new Event('scroll'));

                return JSON.stringify({
                    scrollY: scrollY,
                    scrollHeight: scrollHeight,
                    remaining: remaining
                });
            })();
        """.trimIndent()
    }

    /**
     * Lightweight, dependency-free RFC 8259 JSON parser that works identically on Android runtime
     * and pure JVM unit tests without relying on android.jar `org.json` stubs.
     * Supports objects (`Map<String, Any?>`), arrays (`List<Any?>`), strings, numbers, booleans, null,
     * and tolerates trailing commas often found in real-world `<script type="application/ld+json">` blocks.
     */
    internal object SimpleJson {
        fun parse(text: String): Any? {
            val cleaned = text.trim()
                .removePrefix("<!--")
                .removeSuffix("-->")
                .trim()
            if (cleaned.isEmpty()) return null
            val parser = Parser(cleaned)
            return parser.parseValue()
        }

        private class Parser(private val src: String) {
            private var pos = 0
            private val len = src.length

            private fun skipWhitespace() {
                while (pos < len) {
                    val c = src[pos]
                    if (c == ' ' || c == '\t' || c == '\r' || c == '\n') {
                        pos++
                    } else if (c == '/' && pos + 1 < len && src[pos + 1] == '*') {
                        pos += 2
                        while (pos + 1 < len && !(src[pos] == '*' && src[pos + 1] == '/')) pos++
                        if (pos + 1 < len) pos += 2
                    } else if (c == '/' && pos + 1 < len && src[pos + 1] == '/') {
                        pos += 2
                        while (pos < len && src[pos] != '\n' && src[pos] != '\r') pos++
                    } else {
                        break
                    }
                }
            }

            fun parseValue(): Any? {
                skipWhitespace()
                if (pos >= len) return null
                return when (val c = src[pos]) {
                    '{' -> parseObject()
                    '[' -> parseArray()
                    '"' -> parseString()
                    't', 'T' -> parseLiteral("true", true)
                    'f', 'F' -> parseLiteral("false", false)
                    'n', 'N' -> parseLiteral("null", null)
                    '-', in '0'..'9' -> parseNumber()
                    else -> null
                }
            }

            private fun parseObject(): Map<String, Any?> {
                val map = LinkedHashMap<String, Any?>()
                pos++ // skip '{'
                while (true) {
                    skipWhitespace()
                    if (pos >= len) break
                    if (src[pos] == '}') {
                        pos++
                        break
                    }
                    if (src[pos] == ',') {
                        pos++
                        continue
                    }
                    val key = if (src[pos] == '"') {
                        parseString()
                    } else {
                        break
                    }
                    skipWhitespace()
                    if (pos < len && src[pos] == ':') {
                        pos++
                    } else {
                        break
                    }
                    val value = parseValue()
                    map[key] = value
                    skipWhitespace()
                    if (pos < len && src[pos] == ',') {
                        pos++
                    } else if (pos < len && src[pos] == '}') {
                        pos++
                        break
                    }
                }
                return map
            }

            private fun parseArray(): List<Any?> {
                val list = ArrayList<Any?>()
                pos++ // skip '['
                while (true) {
                    skipWhitespace()
                    if (pos >= len) break
                    if (src[pos] == ']') {
                        pos++
                        break
                    }
                    if (src[pos] == ',') {
                        pos++
                        continue
                    }
                    val value = parseValue()
                    list.add(value)
                    skipWhitespace()
                    if (pos < len && src[pos] == ',') {
                        pos++
                    } else if (pos < len && src[pos] == ']') {
                        pos++
                        break
                    }
                }
                return list
            }

            fun parseString(): String {
                if (pos >= len || src[pos] != '"') return ""
                pos++ // skip opening '"'
                val sb = StringBuilder()
                while (pos < len) {
                    val c = src[pos++]
                    if (c == '"') {
                        return sb.toString()
                    } else if (c == '\\' && pos < len) {
                        when (val esc = src[pos++]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                if (pos + 4 <= len) {
                                    val hex = src.substring(pos, pos + 4)
                                    val code = hex.toIntOrNull(16)
                                    if (code != null) sb.append(code.toChar())
                                    pos += 4
                                }
                            }
                            else -> sb.append(esc)
                        }
                    } else {
                        sb.append(c)
                    }
                }
                return sb.toString()
            }

            private fun parseNumber(): Number? {
                val start = pos
                if (pos < len && (src[pos] == '-' || src[pos] == '+')) pos++
                var isFloat = false
                while (pos < len) {
                    val c = src[pos]
                    if (c in '0'..'9') {
                        pos++
                    } else if (c == '.' || c == 'e' || c == 'E' || c == '+' || c == '-') {
                        isFloat = true
                        pos++
                    } else {
                        break
                    }
                }
                val numStr = src.substring(start, pos)
                return if (isFloat) {
                    numStr.toDoubleOrNull()
                } else {
                    numStr.toLongOrNull() ?: numStr.toDoubleOrNull()
                }
            }

            private fun parseLiteral(expected: String, result: Any?): Any? {
                if (pos + expected.length <= len && src.regionMatches(pos, expected, 0, expected.length, ignoreCase = true)) {
                    pos += expected.length
                    return result
                }
                pos = len
                return null
            }
        }
    }

    private fun Map<*, *>.optString(key: String, default: String = ""): String {
        val v = this[key] ?: return default
        return when (v) {
            is String -> v
            is Number, is Boolean -> v.toString()
            else -> default
        }
    }

    private fun Map<*, *>.optInt(key: String, default: Int = 0): Int {
        val v = this[key] ?: return default
        return when (v) {
            is Number -> v.toInt()
            is String -> v.trim().toIntOrNull() ?: default
            else -> default
        }
    }

    private fun Map<*, *>.optLong(key: String, default: Long = 0L): Long {
        val v = this[key] ?: return default
        return when (v) {
            is Number -> v.toLong()
            is String -> v.trim().toLongOrNull() ?: default
            else -> default
        }
    }

    /**
     * Parses a Schema.org dimension property (number, "1920 px" string, or QuantitativeValue object).
     */
    internal fun parseSchemaDimension(value: Any?): Int? {
        if (value == null) return null
        return when (value) {
            is Number -> value.toInt().takeIf { it > 0 }
            is String -> Regex("""(\d{2,5})""").find(value)?.groupValues?.get(1)?.toIntOrNull()?.takeIf { it > 0 }
            is Map<*, *> -> {
                parseSchemaDimension(value["value"])
                    ?: parseSchemaDimension(value["maxValue"])
                    ?: parseSchemaDimension(value["minValue"])
            }
            is List<*> -> if (value.isNotEmpty()) parseSchemaDimension(value[0]) else null
            else -> null
        }
    }

    /**
     * Parses ISO-8601 duration strings (e.g. "PT1H2M30S", "PT45S", "PT3M") or numeric seconds.
     */
    internal fun parseSchemaDurationSeconds(value: Any?): Long? {
        if (value == null) return null
        if (value is Number) return value.toLong().takeIf { it > 0L }
        val str = value.toString().trim()
        if (str.isBlank()) return null
        str.toLongOrNull()?.let { if (it > 0L) return it }
        val match = Regex("""^P(?:\d+Y)?(?:\d+M)?(?:\d+D)?T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?$""", RegexOption.IGNORE_CASE).find(str)
        if (match != null) {
            val hours = match.groupValues[1].toLongOrNull() ?: 0L
            val mins = match.groupValues[2].toLongOrNull() ?: 0L
            val secs = match.groupValues[3].substringBefore('.').toLongOrNull() ?: 0L
            val total = hours * 3600L + mins * 60L + secs
            if (total > 0L) return total
        }
        return null
    }

    /**
     * Parses Schema.org contentSize (e.g. "4521984", "4.5 MB", "820 KB") into bytes.
     */
    internal fun parseSchemaSizeBytes(value: Any?): Long? {
        if (value == null) return null
        if (value is Number) return value.toLong().takeIf { it > 0L }
        val str = value.toString().trim()
        if (str.isBlank()) return null
        str.toLongOrNull()?.let { if (it > 0L) return it }
        val match = Regex("""(\d+(?:\.\d+)?)\s*(B|KB|MB|GB)""", RegexOption.IGNORE_CASE).find(str)
        if (match != null) {
            val num = match.groupValues[1].toDoubleOrNull() ?: return null
            val unit = match.groupValues[2].uppercase(Locale.ROOT)
            val mult = when (unit) {
                "GB" -> 1024.0 * 1024.0 * 1024.0
                "MB" -> 1024.0 * 1024.0
                "KB" -> 1024.0
                else -> 1.0
            }
            return (num * mult).toLong().takeIf { it > 0L }
        }
        return null
    }

    /**
     * Extracts structured media resources from a Schema.org JSON-LD payload.
     * Supports top-level objects, arrays, `@graph` collections, and deeply nested entities
     * (`VideoObject`, `AudioObject`, `ImageObject`, `MediaObject`, `SocialMediaPosting`, `Article`, `Product`, etc.),
     * preserving thumbnail relationships (`thumbnailUrl`/`thumbnail` paired with `contentUrl`),
     * MIME hints (`encodingFormat`/`fileFormat`), dimensions (`QuantitativeValue`), and titles (`name`/`headline`/`caption`).
     */
    fun extractJsonLdResources(jsonText: String?, baseUrl: String): List<DiscoveredMediaResource> {
        if (jsonText.isNullOrBlank()) return emptyList()
        val trimmed = jsonText.trim()
        val resources = mutableListOf<DiscoveredMediaResource>()

        fun extractAuthorName(authorVal: Any?): String? {
            if (authorVal == null) return null
            return when (authorVal) {
                is String -> authorVal.trim().takeIf { it.isNotEmpty() }
                is Map<*, *> -> authorVal.optString("name", "").trim().takeIf { it.isNotEmpty() }
                is List<*> -> authorVal.firstNotNullOfOrNull { extractAuthorName(it) }
                else -> null
            }
        }

        fun extractUrlsFromNode(nodeVal: Any?, collected: MutableList<String>) {
            if (nodeVal == null) return
            when (nodeVal) {
                is String -> {
                    MediaClassifier.resolveUrl(nodeVal, baseUrl)?.let { collected.add(it) }
                }
                is List<*> -> {
                    for (elem in nodeVal) {
                        extractUrlsFromNode(elem, collected)
                    }
                }
                is Map<*, *> -> {
                    val cu = nodeVal.optString("contentUrl", "").ifBlank { nodeVal.optString("url", "") }
                    if (cu.isNotBlank()) {
                        MediaClassifier.resolveUrl(cu, baseUrl)?.let { collected.add(it) }
                    }
                }
            }
        }

        fun extractTypeNames(obj: Map<*, *>): List<String> {
            val rawType = obj["@type"] ?: obj["type"] ?: return emptyList()
            val list = mutableListOf<String>()
            when (rawType) {
                is String -> list.add(rawType.substringAfterLast('/'))
                is List<*> -> {
                    for (item in rawType) {
                        val s = (item as? String)?.substringAfterLast('/') ?: ""
                        if (s.isNotBlank()) list.add(s)
                    }
                }
            }
            return list
        }

        fun traverse(node: Any?, inheritedTitle: String? = null, inheritedAuthor: String? = null, inheritedThumb: String? = null) {
            if (node == null) return
            when (node) {
                is List<*> -> {
                    for (item in node) {
                        traverse(item, inheritedTitle, inheritedAuthor, inheritedThumb)
                    }
                }
                is Map<*, *> -> {
                    // Handle @graph array if present
                    (node["@graph"] as? List<*>)?.let { graph ->
                        traverse(graph, inheritedTitle, inheritedAuthor, inheritedThumb)
                    }

                    val types = extractTypeNames(node)
                    val lowerTypes = types.map { it.lowercase(Locale.ROOT) }

                    val isVideoObject = lowerTypes.any {
                        it == "videoobject" || it == "movie" || it == "videoclip" || it == "clip" || it == "tvepisode"
                    }
                    val isAudioObject = lowerTypes.any {
                        it == "audioobject" || it == "musicrecording" || it == "podcastepisode" || it == "audioclip"
                    }
                    val isImageObject = lowerTypes.any {
                        it == "imageobject" || it == "photograph" || it == "visualartwork" || it == "barcode"
                    }
                    val isMediaObject = isVideoObject || isAudioObject || isImageObject || lowerTypes.contains("mediaobject")

                    val nodeTitle = node.optString("name", "")
                        .ifBlank { node.optString("headline", "") }
                        .ifBlank { node.optString("caption", "") }
                        .ifBlank { node.optString("alternateName", "") }
                        .trim()
                        .ifBlank { inheritedTitle ?: "" }
                        .takeIf { it.isNotBlank() }

                    val nodeDesc = node.optString("description", "").trim().takeIf { it.isNotBlank() }
                    val nodeAuthor = extractAuthorName(node["author"] ?: node["creator"]) ?: inheritedAuthor

                    // Collect explicit thumbnails on this node
                    val thumbCandidates = mutableListOf<String>()
                    extractUrlsFromNode(node["thumbnailUrl"], thumbCandidates)
                    extractUrlsFromNode(node["thumbnail"], thumbCandidates)
                    val primaryNodeThumb = thumbCandidates.firstOrNull { MediaClassifier.isValidMedia(it) } ?: inheritedThumb

                    if (isMediaObject || node.containsKey("contentUrl")) {
                        val contentUrlRaw = node.optString("contentUrl", "").trim()
                        val urlRaw = node.optString("url", "").trim()
                        val embedUrlRaw = node.optString("embedUrl", "").trim()

                        val mimeHint = node.optString("encodingFormat", "")
                            .ifBlank { node.optString("fileFormat", "") }
                            .trim()
                            .takeIf { it.isNotBlank() && it.contains('/') }

                        val schemaType = when {
                            isVideoObject -> "VideoObject"
                            isAudioObject -> "AudioObject"
                            isImageObject -> "ImageObject"
                            else -> types.firstOrNull()
                        }
                        val typeHint = when {
                            isVideoObject -> "video"
                            isAudioObject -> "audio"
                            isImageObject -> "image"
                            else -> types.firstOrNull()
                        }

                        val w = parseSchemaDimension(node["width"])
                        val h = parseSchemaDimension(node["height"])
                        val durationSec = parseSchemaDurationSeconds(node["duration"])
                        val sizeBytes = parseSchemaSizeBytes(node["contentSize"])

                        // Also inspect nested encoding / encodings array for multi-bitrate / multi-res variants
                        val variants = mutableListOf<MediaVariantCandidate>()
                        val companions = mutableListOf<String>()
                        thumbCandidates.filter { MediaClassifier.isValidMedia(it) }.forEach { companions.add(it) }

                        fun collectEncodingVariants(encVal: Any?) {
                            when (encVal) {
                                is Map<*, *> -> {
                                    val encUrl = MediaClassifier.resolveUrl(
                                        encVal.optString("contentUrl", "").ifBlank { encVal.optString("url", "") },
                                        baseUrl
                                    )
                                    if (encUrl != null && MediaClassifier.isValidMedia(encUrl)) {
                                        val encW = parseSchemaDimension(encVal["width"])
                                        val encH = parseSchemaDimension(encVal["height"])
                                        val encMime = encVal.optString("encodingFormat", "").takeIf { it.contains('/') } ?: mimeHint
                                        val encDesc = if (encW != null && encH != null) "${encW}x${encH}" else null
                                        variants.add(
                                            MediaVariantCandidate(
                                                url = encUrl,
                                                descriptor = encDesc,
                                                width = encW,
                                                height = encH,
                                                mimeType = encMime,
                                                source = ExtractionSource.JSON_LD
                                            )
                                        )
                                        companions.add(encUrl)
                                    }
                                }
                                is List<*> -> {
                                    for (item in encVal) {
                                        collectEncodingVariants(item)
                                    }
                                }
                            }
                        }
                        collectEncodingVariants(node["encoding"])
                        collectEncodingVariants(node["encodings"])

                        val resolvedContent = MediaClassifier.resolveUrl(contentUrlRaw, baseUrl)?.takeIf { MediaClassifier.isValidMedia(it) }
                        val resolvedUrl = MediaClassifier.resolveUrl(urlRaw, baseUrl)?.takeIf { candidate ->
                            if (!MediaClassifier.isValidMedia(candidate)) false
                            else if (isImageObject || isVideoObject || isAudioObject) {
                                val cleanP = candidate.substringBefore('?').substringBefore('#').lowercase(Locale.ROOT)
                                val hasMediaExt = MediaClassifier.KNOWN_MEDIA_EXTENSIONS.any { cleanP.endsWith(".$it") }
                                hasMediaExt || resolvedContent != null || !mimeHint.isNullOrBlank()
                            } else false
                        }
                        val resolvedEmbed = MediaClassifier.resolveUrl(embedUrlRaw, baseUrl)?.takeIf { candidate ->
                            val cleanP = candidate.substringBefore('?').substringBefore('#').lowercase(Locale.ROOT)
                            MediaClassifier.isValidMedia(candidate) && MediaClassifier.KNOWN_MEDIA_EXTENSIONS.any { cleanP.endsWith(".$it") }
                        }

                        val primaryCandidate = resolvedContent ?: resolvedUrl ?: resolvedEmbed ?: variants.firstOrNull()?.url
                        if (primaryCandidate != null) {
                            val resHint = if (w != null && h != null) "${w}x${h}" else null
                            variants.add(
                                0,
                                MediaVariantCandidate(
                                    url = primaryCandidate,
                                    descriptor = resHint,
                                    width = w,
                                    height = h,
                                    mimeType = mimeHint,
                                    source = ExtractionSource.JSON_LD
                                )
                            )
                            val meta = mutableMapOf<String, String>()
                            schemaType?.let { meta["schema_type"] = it }
                            durationSec?.let { meta["duration"] = it.toString() }
                            nodeAuthor?.let { meta["author"] = it }
                            nodeDesc?.let { meta["description"] = it.take(300) }
                            node.optString("uploadDate", "").ifBlank { node.optString("datePublished", "") }
                                .takeIf { it.isNotBlank() }?.let { meta["upload_date"] = it }

                            resources.add(
                                DiscoveredMediaResource(
                                    primaryUrl = primaryCandidate,
                                    variants = variants,
                                    thumbnailUrl = primaryNodeThumb,
                                    companionUrls = companions.distinct(),
                                    source = ExtractionSource.JSON_LD,
                                    mediaTypeHint = typeHint,
                                    mimeHint = mimeHint,
                                    titleHint = nodeTitle,
                                    descriptionHint = nodeDesc,
                                    authorHint = nodeAuthor,
                                    durationSeconds = durationSec,
                                    width = w,
                                    height = h,
                                    resolutionHint = resHint,
                                    sizeBytes = sizeBytes,
                                    domSelector = "script[type=application/ld+json]",
                                    metadata = meta
                                )
                            )
                        } else if (primaryNodeThumb != null && (isVideoObject || isImageObject)) {
                            // Only emit standalone thumbnail if no contentUrl/embedUrl existed on the media object
                            resources.add(
                                DiscoveredMediaResource(
                                    primaryUrl = primaryNodeThumb,
                                    source = ExtractionSource.JSON_LD,
                                    mediaTypeHint = "image",
                                    titleHint = nodeTitle,
                                    authorHint = nodeAuthor,
                                    width = w,
                                    height = h,
                                    domSelector = "script[type=application/ld+json]"
                                )
                            )
                        }
                    }

                    // Handle `image` property on non-ImageObject containers (e.g. Article, SocialMediaPosting, Product, VideoObject)
                    if (!isImageObject && node.containsKey("image")) {
                        val imgProp = node["image"]
                        when (imgProp) {
                            is String -> {
                                val resolvedImg = MediaClassifier.resolveUrl(imgProp, baseUrl)
                                if (resolvedImg != null && MediaClassifier.isValidMedia(resolvedImg)) {
                                    // If this node is a VideoObject or has a nested `video` property, treat `image` as its thumbnail/companion
                                    if (!isVideoObject && !node.containsKey("video")) {
                                        resources.add(
                                            DiscoveredMediaResource(
                                                primaryUrl = resolvedImg,
                                                source = ExtractionSource.JSON_LD,
                                                mediaTypeHint = "image",
                                                titleHint = nodeTitle,
                                                authorHint = nodeAuthor,
                                                domSelector = "script[type=application/ld+json]"
                                            )
                                        )
                                    }
                                }
                            }
                            is Map<*, *> -> traverse(imgProp, nodeTitle, nodeAuthor, primaryNodeThumb)
                            is List<*> -> {
                                for (elem in imgProp) {
                                    if (elem is String) {
                                        val resolvedImg = MediaClassifier.resolveUrl(elem, baseUrl)
                                        if (resolvedImg != null && MediaClassifier.isValidMedia(resolvedImg) && !isVideoObject) {
                                            resources.add(
                                                DiscoveredMediaResource(
                                                    primaryUrl = resolvedImg,
                                                    source = ExtractionSource.JSON_LD,
                                                    mediaTypeHint = "image",
                                                    titleHint = nodeTitle,
                                                    authorHint = nodeAuthor,
                                                    domSelector = "script[type=application/ld+json]"
                                                )
                                            )
                                        }
                                    } else {
                                        traverse(elem, nodeTitle, nodeAuthor, primaryNodeThumb)
                                    }
                                }
                            }
                        }
                    }

                    // Traverse nested media-bearing properties
                    val nestedKeys = listOf(
                        "video", "audio", "associatedMedia", "mainEntity", "mainEntityOfPage",
                        "subjectOf", "hasPart", "itemListElement", "workExample", "sharedContent",
                        "trailer", "item"
                    )
                    for (key in nestedKeys) {
                        if (node.containsKey(key)) {
                            traverse(node[key], nodeTitle, nodeAuthor, primaryNodeThumb)
                        }
                    }
                }
            }
        }

        try {
            val root = SimpleJson.parse(trimmed)
            traverse(root)
        } catch (_: Exception) {
        }

        return resources
    }

    /**
     * Converts a structured [DiscoveredMediaResource] into a validated, reconciled [ScrapedMediaItem].
     * Evaluates all candidate variants, selects the highest-quality primary URL, establishes
     * explicit thumbnail relationships, records companion deduplication keys for sibling variants/posters,
     * and preserves semantic metadata and download headers.
     */
    fun buildMediaItemFromResource(
        resource: DiscoveredMediaResource,
        baseUrl: String,
        indexHint: Int = 0
    ): ScrapedMediaItem? {
        data class EvaluatedCandidate(
            val rawUrl: String,
            val resolvedUrl: String,
            val cleanedUrl: String,
            val resolvedInfo: MediaClassifier.ResolvedMediaInfo,
            val classification: ClassificationResult,
            val variant: MediaVariantCandidate
        )

        val rawCandidates = if (resource.variants.isNotEmpty()) {
            resource.variants
        } else {
            listOf(
                MediaVariantCandidate(
                    url = resource.primaryUrl,
                    descriptor = resource.resolutionHint,
                    width = resource.width,
                    height = resource.height,
                    mimeType = resource.mimeHint,
                    source = resource.source
                )
            )
        }

        val evaluated = mutableListOf<EvaluatedCandidate>()
        for (cand in rawCandidates) {
            val trimmed = cand.url.trim()
            if (trimmed.isBlank() || trimmed.startsWith("blob:", ignoreCase = true)) continue
            if (trimmed.startsWith("data:", ignoreCase = true) && !MediaClassifier.isSubstantialDataUri(trimmed)) continue
            if (MediaClassifier.isMediaFragment(trimmed)) continue
            if (AdBlockEngine.isAdOrTracker(trimmed)) continue

            val resolved = MediaClassifier.resolveUrl(trimmed, baseUrl) ?: continue
            if (!MediaClassifier.isValidMedia(resolved)) continue
            if (MediaClassifier.isMediaFragment(resolved)) continue

            val resolvedInfo = MediaClassifier.resolveOriginalMedia(resolved)
            val cleanedUrl = MediaClassifier.cleanMediaUrl(resolvedInfo.mediaUrl)
            if (MediaClassifier.isMediaFragment(cleanedUrl)) continue

            val effectiveMime = cand.mimeType ?: resource.mimeHint
            val classification = MediaClassifier.classify(
                url = cleanedUrl,
                mimeHint = effectiveMime,
                typeHint = resource.mediaTypeHint
            )
            val isVidAudStream = classification.isVideo || classification.isAudio || classification.isStream
            val w = cand.width ?: resource.width
            val h = cand.height ?: resource.height
            val checkTitle = resolvedInfo.cleanTitle ?: resource.titleHint

            if (ContentAwareMediaFilter.isUiChromeUrl(
                    url = resolved,
                    title = checkTitle,
                    width = w,
                    height = h,
                    isVideoOrAudioOrStream = isVidAudStream
                ) || ContentAwareMediaFilter.isUiChromeUrl(
                    url = cleanedUrl,
                    title = checkTitle,
                    width = w,
                    height = h,
                    isVideoOrAudioOrStream = isVidAudStream
                )
            ) {
                continue
            }

            evaluated.add(
                EvaluatedCandidate(
                    rawUrl = trimmed,
                    resolvedUrl = resolved,
                    cleanedUrl = cleanedUrl,
                    resolvedInfo = resolvedInfo,
                    classification = classification,
                    variant = cand
                )
            )
        }

        if (evaluated.isEmpty()) return null

        // Select the highest-quality variant candidate
        fun hasExplicitExtension(url: String): Boolean {
            val clean = url.substringBefore('?').substringBefore('#').lowercase(Locale.ROOT)
            return MediaClassifier.KNOWN_MEDIA_EXTENSIONS.any { clean.endsWith(".$it") }
        }

        val resolvedResourceThumb = resource.thumbnailUrl?.takeIf { it.isNotBlank() }?.let {
            MediaClassifier.resolveUrl(it, baseUrl)
        }

        var bestCand = evaluated[0]
        for (i in 1 until evaluated.size) {
            val curr = evaluated[i]
            val currIsRich = curr.classification.isVideo || curr.classification.isAudio || curr.classification.isStream
            val bestIsRich = bestCand.classification.isVideo || bestCand.classification.isAudio || bestCand.classification.isStream
            if (currIsRich && !bestIsRich) {
                bestCand = curr
                continue
            }
            if (bestIsRich && !currIsRich) {
                continue
            }
            if (bestCand.variant.descriptor == "Full Link" && curr.variant.descriptor != "Full Link") {
                val isPreviewImg = resolvedResourceThumb != null &&
                        curr.resolvedUrl == resolvedResourceThumb &&
                        curr.variant.source != ExtractionSource.SRCSET
                if (isPreviewImg) continue
            }

            val currDimHint = if (curr.variant.width != null && curr.variant.height != null) {
                "${curr.variant.width}x${curr.variant.height}"
            } else null
            val currResHint = MediaClassifier.reconcileResolutionHint(currDimHint, curr.variant.descriptor)
                ?: resource.resolutionHint
            val bestDimHint = if (bestCand.variant.width != null && bestCand.variant.height != null) {
                "${bestCand.variant.width}x${bestCand.variant.height}"
            } else null
            val bestResHint = MediaClassifier.reconcileResolutionHint(bestDimHint, bestCand.variant.descriptor)
                ?: resource.resolutionHint

            val currDummy = ScrapedMediaItem(
                id = "curr",
                url = curr.cleanedUrl,
                title = "",
                format = curr.classification.format,
                resolutionHint = currResHint
            )
            val bestDummy = ScrapedMediaItem(
                id = "best",
                url = bestCand.cleanedUrl,
                title = "",
                format = bestCand.classification.format,
                resolutionHint = bestResHint
            )
            val cmp = MediaClassifier.compareMediaQuality(currDummy, bestDummy)
            if (cmp > 0 || (cmp == 0 && hasExplicitExtension(curr.cleanedUrl) && !hasExplicitExtension(bestCand.cleanedUrl))) {
                bestCand = curr
            }
        }

        val cleanedUrl = bestCand.cleanedUrl
        val classification = bestCand.classification
        val resolvedInfo = bestCand.resolvedInfo
        val effectiveSource = bestCand.variant.source

        // Resolve explicit poster / thumbnail relationship
        val resolvedExplicitThumb = resource.thumbnailUrl?.takeIf { it.isNotBlank() }?.let { rawThumb ->
            MediaClassifier.resolveUrl(rawThumb, baseUrl)?.takeIf {
                MediaClassifier.isValidMedia(it) && !MediaClassifier.isMediaFragment(it) && !AdBlockEngine.isAdOrTracker(it)
            }
        }

        // For multi-variant image elements (e.g. <picture>, srcset, <a href><img/></a>),
        // use a valid raster preview URL as thumbnailUrl if the master URL was unwrapped
        val variantPreviewThumb = evaluated
            .firstOrNull { it.classification.category == MediaCategory.IMAGES && it.resolvedUrl != cleanedUrl }
            ?.resolvedUrl

        val thumb = resolvedInfo.thumbnailUrl
            ?: resolvedExplicitThumb
            ?: variantPreviewThumb
            ?: if (classification.category == MediaCategory.IMAGES) bestCand.resolvedUrl else null

        // Compute structured resolutionHint from explicit dimensions or descriptor
        val bestW = bestCand.variant.width ?: resource.width
        val bestH = bestCand.variant.height ?: resource.height
        val dimensionString = when {
            bestW != null && bestH != null && bestW > 0 && bestH > 0 -> "${bestW}x${bestH}"
            bestW != null && bestW > 0 -> "${bestW}w"
            else -> null
        }
        val finalResolutionHint = MediaClassifier.reconcileResolutionHint(
            preferredHint = dimensionString,
            secondaryHint = bestCand.variant.descriptor?.takeIf { MediaClassifier.isMeaningfulResolutionHint(it) }
                ?: resource.resolutionHint?.takeIf { MediaClassifier.isMeaningfulResolutionHint(it) },
            preferredUrl = cleanedUrl
        )

        // Compute semantic title (reconciling CDN clean filename, DOM/JSON-LD titleHint, and fallback derived filename)
        val fallbackFileName = MediaClassifier.deriveFileName(cleanedUrl, classification.format, indexHint)
        val rawTitleCandidate = resolvedInfo.cleanTitle ?: fallbackFileName
        val finalTitle = if (!resource.titleHint.isNullOrBlank()) {
            MediaClassifier.reconcileTitle(
                preferredTitle = rawTitleCandidate,
                secondaryTitle = resource.titleHint.trim(),
                format = classification.format,
                preferredUrl = cleanedUrl
            )
        } else {
            rawTitleCandidate
        }

        // Collect all companion deduplication keys (posters, thumbnails, sibling srcset/<picture>/<a> variants)
        val companionKeys = LinkedHashSet<String>()
        resolvedExplicitThumb?.let { companionKeys.add(MediaClassifier.deduplicationKey(it)) }
        for (ev in evaluated) {
            companionKeys.add(MediaClassifier.deduplicationKey(ev.resolvedUrl))
            companionKeys.add(MediaClassifier.deduplicationKey(ev.cleanedUrl))
        }
        for (compUrl in resource.companionUrls) {
            MediaClassifier.resolveUrl(compUrl, baseUrl)?.let { absComp ->
                if (MediaClassifier.isValidMedia(absComp)) {
                    companionKeys.add(MediaClassifier.deduplicationKey(absComp))
                }
            }
        }
        companionKeys.remove(MediaClassifier.deduplicationKey(cleanedUrl))

        val headers = mutableMapOf<String, String>()
        headers["Referer"] = baseUrl
        headers["User-Agent"] = OkHttpDownloader.DEFAULT_USER_AGENT
        val cookieStr = OkHttpDownloader.sharedCookieJar.getCookieString(baseUrl)
        if (cookieStr.isNotBlank()) {
            headers["Cookie"] = cookieStr
        }

        val metadataMap = LinkedHashMap<String, String>()
        metadataMap.putAll(resource.metadata)
        finalResolutionHint?.let { metadataMap["resolution"] = it }
        (bestCand.variant.mimeType ?: resource.mimeHint)?.let { metadataMap["mime_hint"] = it }
        resource.mediaTypeHint?.let { metadataMap["media_type_hint"] = it }
        resource.titleHint?.takeIf { it.isNotBlank() }?.let { metadataMap["title_hint"] = it }
        resource.descriptionHint?.takeIf { it.isNotBlank() }?.let { metadataMap["description"] = it }
        resource.authorHint?.takeIf { it.isNotBlank() }?.let { metadataMap["author"] = it }
        resource.durationSeconds?.let { metadataMap["duration"] = it.toString() }
        resolvedExplicitThumb?.let { metadataMap["poster_url"] = it }
        if (companionKeys.isNotEmpty()) {
            metadataMap["companion_keys"] = companionKeys.joinToString("|")
        }
        metadataMap["source_url"] = baseUrl

        val estimatedSize = resource.sizeBytes ?: MediaClassifier.estimateDataUriSizeBytes(cleanedUrl)

        return ScrapedMediaItem(
            id = "captured_${indexHint}_${System.currentTimeMillis()}_${cleanedUrl.hashCode()}",
            url = cleanedUrl,
            title = finalTitle,
            isVideo = classification.isVideo,
            isAudio = classification.isAudio,
            isStream = classification.isStream,
            category = classification.category,
            format = classification.format,
            thumbnailUrl = thumb,
            source = effectiveSource.label,
            mimeType = classification.mimeType,
            resolutionHint = finalResolutionHint,
            sizeBytes = estimatedSize,
            provenance = MediaProvenance(
                extractorEngine = "MediaCaptureEngine (${effectiveSource.label})",
                pageUrl = baseUrl,
                domSelector = resource.domSelector
                    ?: if (effectiveSource == ExtractionSource.NETWORK_INTERCEPT) "network_request" else null
            ),
            metadata = metadataMap,
            downloadHeaders = headers
        )
    }

    /**
     * Builds and validates a ScrapedMediaItem with provenance, clean titles,
     * download headers (User-Agent, Referer, Cookie), and thumbnail classification.
     */
    fun buildMediaItem(
        rawUrl: String,
        source: ExtractionSource,
        baseUrl: String,
        poster: String? = null,
        resolutionHint: String? = null,
        mimeHint: String? = null,
        indexHint: Int = 0,
        typeHint: String? = null,
        titleHint: String? = null,
        width: Int? = null,
        height: Int? = null,
        sizeBytes: Long? = null,
        companionUrls: List<String> = emptyList(),
        domSelector: String? = null
    ): ScrapedMediaItem? {
        val inferredTypeHint = typeHint ?: when (resolutionHint?.lowercase(Locale.ROOT)) {
            "video" -> "video"
            "audio" -> "audio"
            "stream" -> "stream"
            else -> null
        }
        val cleanedResHint = resolutionHint?.takeIf { MediaClassifier.isMeaningfulResolutionHint(it) }
        val resource = DiscoveredMediaResource(
            primaryUrl = rawUrl,
            thumbnailUrl = poster,
            companionUrls = companionUrls,
            source = source,
            mediaTypeHint = inferredTypeHint,
            mimeHint = mimeHint,
            titleHint = titleHint,
            width = width,
            height = height,
            resolutionHint = cleanedResHint,
            sizeBytes = sizeBytes,
            domSelector = domSelector
        )
        return buildMediaItemFromResource(resource, baseUrl, indexHint)
    }

    /**
     * Unified network request interception for both BrowserMediaExtractor and DirectBrowserView.
     * Preserves Accept header MIME and media type context so extensionless video/audio/stream
     * network requests are accurately classified.
     */
    fun shouldInterceptRequest(
        request: WebResourceRequest?,
        baseUrl: String,
        onMediaDiscovered: (ScrapedMediaItem) -> Unit
    ): WebResourceResponse? {
        if (request == null) return null
        val reqUrl = request.url.toString()

        // 1. Instant zero-payload response for ad/tracker networks
        if (AdBlockEngine.isAdOrTracker(reqUrl)) {
            return AdBlockEngine.createEmptyResponse()
        }

        // 2. Reject streaming slice fragments (.ts slices, dash segments)
        if (MediaClassifier.isMediaFragment(reqUrl)) {
            return null
        }

        val reqLower = reqUrl.lowercase()
        val cleanReqPath = reqLower.substringBefore("?").substringBefore("#")
        val headers = request.requestHeaders ?: emptyMap()
        val acceptHeader = headers["Accept"]?.lowercase() ?: headers["accept"]?.lowercase() ?: ""

        // Reject non-media API, logging, telemetry endpoints
        val isNonMediaEndpoint = cleanReqPath.contains("/api/") || cleanReqPath.contains("/apis/") ||
                cleanReqPath.contains("/youtubei/") || cleanReqPath.contains("/stats/") ||
                cleanReqPath.contains("/log") || cleanReqPath.contains("/logging") ||
                cleanReqPath.contains("/ptracking") || cleanReqPath.contains("/beacon") ||
                cleanReqPath.contains("/telemetry") || cleanReqPath.contains("/metrics") ||
                cleanReqPath.contains("generate_204") || cleanReqPath.contains("/recaptcha") ||
                cleanReqPath.contains("/embed/") || cleanReqPath.contains("play.google.com/log") ||
                cleanReqPath.contains("youtube.com/api/") || cleanReqPath.contains("/wiki/") ||
                cleanReqPath.contains("/geohack") || cleanReqPath.contains("centralautologin")

        if (isNonMediaEndpoint) return null

        val isNonMediaPage = cleanReqPath.endsWith(".html") || cleanReqPath.endsWith(".htm") ||
                cleanReqPath.endsWith(".php") || cleanReqPath.endsWith(".js") || cleanReqPath.endsWith(".css") ||
                cleanReqPath.endsWith(".json") || cleanReqPath.endsWith(".xml") || cleanReqPath.endsWith(".txt") ||
                cleanReqPath.endsWith(".do") || cleanReqPath.endsWith(".asp") || cleanReqPath.endsWith(".aspx")

        if (isNonMediaPage) return null

        val isHlsStream = cleanReqPath.endsWith(".m3u8") || cleanReqPath.contains("chunklist") ||
                acceptHeader.contains("mpegurl")
        val isDashStream = cleanReqPath.endsWith(".mpd") || acceptHeader.contains("dash+xml")
        val isStream = isHlsStream || isDashStream

        val isVideo = isStream || cleanReqPath.endsWith(".mp4") || cleanReqPath.endsWith(".webm") ||
                cleanReqPath.endsWith(".mov") || cleanReqPath.endsWith(".mkv") ||
                acceptHeader.startsWith("video/")

        val isAudio = cleanReqPath.endsWith(".mp3") || cleanReqPath.endsWith(".m4a") ||
                cleanReqPath.endsWith(".aac") || cleanReqPath.endsWith(".wav") ||
                cleanReqPath.endsWith(".ogg") || cleanReqPath.endsWith(".flac") ||
                cleanReqPath.endsWith(".opus") || acceptHeader.startsWith("audio/")

        val hasImageExt = cleanReqPath.endsWith(".jpg") || cleanReqPath.endsWith(".jpeg") ||
                cleanReqPath.endsWith(".png") || cleanReqPath.endsWith(".webp") ||
                cleanReqPath.endsWith(".gif") || cleanReqPath.endsWith(".avif") ||
                cleanReqPath.endsWith(".svg") || cleanReqPath.endsWith(".bmp") ||
                cleanReqPath.contains("/vi/") || cleanReqPath.contains("/vi_webp/") ||
                Regex("""[?&](?:format|fmt|ext)=(?:jpg|jpeg|png|webp|avif)""").containsMatchIn(reqLower)

        val isImage = hasImageExt && !acceptHeader.contains("text/html")

        if (isVideo || isAudio || isImage) {
            val cleanReqUrl = if (isVideo) MediaClassifier.cleanMediaUrl(reqUrl) else reqUrl
            val inferredMime = when {
                isHlsStream -> "application/x-mpegURL"
                isDashStream -> "application/dash+xml"
                acceptHeader.startsWith("video/") -> acceptHeader.substringBefore(",").substringBefore(";").trim()
                acceptHeader.startsWith("audio/") -> acceptHeader.substringBefore(",").substringBefore(";").trim()
                else -> null
            }
            val inferredType = when {
                isStream -> "stream"
                isAudio -> "audio"
                isVideo -> "video"
                else -> "image"
            }
            val item = buildMediaItem(
                rawUrl = cleanReqUrl,
                source = ExtractionSource.NETWORK_INTERCEPT,
                baseUrl = baseUrl,
                mimeHint = inferredMime,
                typeHint = inferredType,
                domSelector = "network_request"
            )
            if (item != null) {
                onMediaDiscovered(item)
            }
        }

        return null
    }

    /**
     * Parses a single JSON object emitted by getJsDomScanScript() or getMutationObserverScript()
     * into one or more ScrapedMediaItems (handling both DOM resources and JSON_LD_RAW payloads).
     */
    internal fun parseJsonResourceEntry(
        obj: Map<*, *>,
        baseUrl: String,
        indexHint: Int = 0
    ): List<ScrapedMediaItem> {
        val sTag = obj.optString("s", "DOM")
        if (sTag == "JSON_LD_RAW" || obj.containsKey("jsonLd")) {
            val rawLd = obj.optString("jsonLd", "")
            val ldResources = extractJsonLdResources(rawLd, baseUrl)
            return ldResources.mapIndexedNotNull { idx, res ->
                buildMediaItemFromResource(res, baseUrl, indexHint + idx)
            }
        }

        val rawUrl = obj.optString("u", "")
        if (rawUrl.isBlank()) return emptyList()

        val source = when (sTag) {
            "CSS" -> ExtractionSource.CSS_BACKGROUND
            "SRCSET" -> ExtractionSource.SRCSET
            "IFRAME" -> ExtractionSource.IFRAME
            "JSON_LD" -> ExtractionSource.JSON_LD
            "OPEN_GRAPH" -> ExtractionSource.OPEN_GRAPH
            else -> ExtractionSource.DOM_SCRAPE
        }

        val poster = obj.optString("p", "").ifBlank { null }
        val res = obj.optString("r", "").ifBlank { null }
        val typeHint = obj.optString("t", "").ifBlank {
            when (res?.lowercase(Locale.ROOT)) {
                "video" -> "video"
                "audio" -> "audio"
                else -> null
            }
        }
        val mimeHint = obj.optString("m", "").ifBlank { null }
        val titleHint = obj.optString("title", "").ifBlank { null }
        val w = obj.optInt("w", 0).takeIf { it > 0 }
        val h = obj.optInt("h", 0).takeIf { it > 0 }
        val dur = obj.optLong("d", 0L).takeIf { it > 0L }
        val sel = obj.optString("sel", "").ifBlank { null }

        val variantsList = mutableListOf<MediaVariantCandidate>()
        val variantsArr = obj["variants"] as? List<*>
        if (variantsArr != null) {
            for (vItem in variantsArr) {
                val vObj = vItem as? Map<*, *> ?: continue
                val vu = vObj.optString("u", "")
                if (vu.isNotBlank()) {
                    val vsTag = vObj.optString("s", sTag)
                    val vSource = when (vsTag) {
                        "SRCSET" -> ExtractionSource.SRCSET
                        "CSS" -> ExtractionSource.CSS_BACKGROUND
                        "OPEN_GRAPH" -> ExtractionSource.OPEN_GRAPH
                        "JSON_LD" -> ExtractionSource.JSON_LD
                        else -> source
                    }
                    variantsList.add(
                        MediaVariantCandidate(
                            url = vu,
                            descriptor = vObj.optString("r", "").ifBlank { null },
                            width = vObj.optInt("w", 0).takeIf { it > 0 },
                            height = vObj.optInt("h", 0).takeIf { it > 0 },
                            mimeType = vObj.optString("m", "").ifBlank { mimeHint },
                            source = vSource
                        )
                    )
                }
            }
        }

        val companionsList = mutableListOf<String>()
        val compArr = obj["c"] as? List<*>
        if (compArr != null) {
            for (cItem in compArr) {
                val cu = (cItem as? String)?.trim() ?: ""
                if (cu.isNotBlank()) companionsList.add(cu)
            }
        }

        val resource = DiscoveredMediaResource(
            primaryUrl = rawUrl,
            variants = variantsList,
            thumbnailUrl = poster,
            companionUrls = companionsList,
            source = source,
            mediaTypeHint = typeHint,
            mimeHint = mimeHint,
            titleHint = titleHint,
            durationSeconds = dur,
            width = w,
            height = h,
            resolutionHint = res?.takeIf { MediaClassifier.isMeaningfulResolutionHint(it) },
            domSelector = sel
        )
        val built = buildMediaItemFromResource(resource, baseUrl, indexHint)
        return if (built != null) listOf(built) else emptyList()
    }

    /**
     * Parses a structured JSON resource string reported by `EmreBridge.reportResource(json)`.
     */
    fun parseStructuredResourceJson(
        resourceJson: String?,
        baseUrl: String
    ): List<ScrapedMediaItem> {
        if (resourceJson.isNullOrBlank() || resourceJson == "null") return emptyList()
        return try {
            val firstParsed = SimpleJson.parse(resourceJson)
            val obj = when (firstParsed) {
                is String -> SimpleJson.parse(firstParsed) as? Map<*, *>
                is Map<*, *> -> firstParsed
                else -> null
            } ?: return emptyList()
            MediaClassifier.deduplicateScrapedItems(parseJsonResourceEntry(obj, baseUrl, 0))
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * Parses the JSON array returned by getJsDomScanScript() and reconciles all discovered
     * structured resources (collapsing variants, pairing posters/thumbnails, and merging metadata).
     */
    fun parseJsDomScanResult(
        resultJson: String?,
        baseUrl: String
    ): List<ScrapedMediaItem> {
        if (resultJson.isNullOrBlank() || resultJson == "null") return emptyList()

        return try {
            val firstParsed = SimpleJson.parse(resultJson)
            val jsonArray = when (firstParsed) {
                is String -> SimpleJson.parse(firstParsed) as? List<*>
                is List<*> -> firstParsed
                else -> null
            } ?: return emptyList()

            val rawResults = mutableListOf<ScrapedMediaItem>()
            for (elem in jsonArray) {
                val obj = elem as? Map<*, *> ?: continue
                rawResults.addAll(parseJsonResourceEntry(obj, baseUrl, rawResults.size))
            }
            MediaClassifier.deduplicateScrapedItems(rawResults)
        } catch (_: Exception) {
            emptyList()
        }
    }
}
