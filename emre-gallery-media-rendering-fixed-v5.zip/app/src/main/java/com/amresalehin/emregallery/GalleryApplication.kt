package com.amresalehin.emregallery

import android.app.Application
import android.content.Context
import android.os.Build
import coil.Coil
import coil.ImageLoader
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder
import coil.decode.VideoFrameDecoder
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.amresalehin.emregallery.data.MediaStoreThumbnailFetcher
import com.amresalehin.emregallery.data.OkHttpDownloader
import kotlinx.coroutines.Dispatchers
import java.io.File

class GalleryApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager
        val isLowRam = activityManager?.isLowRamDevice ?: false

        // Unconstrained memory caching: Allocate up to 45% (30% on low-RAM) of JVM heap to Coil.
        // With largeHeap enabled, this unlocks hundreds of megabytes for raw pre-decoded bitmaps,
        // avoiding recurring decompression bottlenecks during 120Hz continuous scrolling.
        val cachePercent = if (isLowRam) 0.30 else 0.45

        // Unconstrained concurrency: Utilize full Dispatchers without artificial core-capping
        // so that multi-core processors decode thumbnails at maximum throughput.
        val imageIoDispatcher = Dispatchers.IO
        val imageComputeDispatcher = Dispatchers.Default

        val imageLoader = ImageLoader.Builder(this)
            .okHttpClient { OkHttpDownloader.client }
            .fetcherDispatcher(imageIoDispatcher)
            .decoderDispatcher(imageComputeDispatcher)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(cachePercent)
                    .strongReferencesEnabled(true)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(File(cacheDir, "image_cache"))
                    .maxSizeBytes(1073741824L) // 1GB disk cache
                    .build()
            }
            .components {
                add(MediaStoreThumbnailFetcher.Factory(this@GalleryApplication))
                if (Build.VERSION.SDK_INT >= 28) {
                    add(ImageDecoderDecoder.Factory())
                } else {
                    add(GifDecoder.Factory())
                }
                add(VideoFrameDecoder.Factory())
            }
            .bitmapConfig(if (isLowRam) android.graphics.Bitmap.Config.RGB_565 else android.graphics.Bitmap.Config.ARGB_8888)
            .allowRgb565(true)
            .allowHardware(true)
            .crossfade(true)
            .crossfade(150)
            .respectCacheHeaders(false)
            .build()
        Coil.setImageLoader(imageLoader)

        // Deterministic registration of both face recognition engines
        com.amresalehin.emregallery.face.FaceEngineRegistry.register(com.amresalehin.emregallery.face.BuffaloLFaceEngineFactory)
        com.amresalehin.emregallery.face.FaceEngineRegistry.register(com.amresalehin.emregallery.face.EnteFaceEngineFactory)
        com.amresalehin.emregallery.face.FaceProcessingCoordinator.init(this)

        // Initialize Chaquopy Python SDK and gallery-dl media engine
        com.amresalehin.emregallery.data.GalleryDlEngine.init(this)

        // Initialize DownloadActivityManager to restore persisted downloads and resume retry schedules
        com.amresalehin.emregallery.data.DownloadActivityManager.initialize(this)

        // Pre-warm Chromium WebView engine on cold start so automatic scraping
        // never stalls waiting for cold browser initialization
        warmupChromium(this)
    }

    companion object {
        fun warmupChromium(context: Context) {
            runCatching {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    try {
                        val cm = android.webkit.CookieManager.getInstance()
                        cm.setAcceptCookie(true)
                        val warmupWv = android.webkit.WebView(context)
                        cm.setAcceptThirdPartyCookies(warmupWv, true)
                        warmupWv.settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                        }
                        warmupWv.destroy()
                    } catch (_: Throwable) {}
                }
            }
        }
    }

    /**
     * Emre never limits itself when Android is not limiting it.
     * When Android signals genuine memory constraints via onTrimMemory,
     * memory caches are trimmed or cleared according to severity.
     */
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        runCatching {
            val coilCache = Coil.imageLoader(this).memoryCache
            when {
                level >= TRIM_MEMORY_RUNNING_CRITICAL || level >= TRIM_MEMORY_COMPLETE -> {
                    coilCache?.clear()
                    com.amresalehin.emregallery.face.FaceThumbnailHelper.clearCache()
                }
                level >= TRIM_MEMORY_RUNNING_LOW || level >= TRIM_MEMORY_BACKGROUND -> {
                    coilCache?.trimMemory(level)
                    com.amresalehin.emregallery.face.FaceThumbnailHelper.trimMemory(level)
                }
            }
        }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        runCatching {
            Coil.imageLoader(this).memoryCache?.clear()
            com.amresalehin.emregallery.face.FaceThumbnailHelper.clearCache()
        }
    }
}
