package com.amresalehin.emregallery

import com.amresalehin.emregallery.data.MediaCategory
import com.amresalehin.emregallery.data.MediaClassifier
import com.amresalehin.emregallery.data.MediaProvenance
import com.amresalehin.emregallery.data.ScrapedMediaItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MediaDeduplicationPureUnitTest {

    @Test
    fun testPinterestResolutionAndFormatVariantDeduplication() {
        val hash = "f732ca2684db4685ff263b65cb466ff4"
        val p1 = "f7"
        val p2 = "32"
        val p3 = "ca"

        val url757 = "https://i.pinimg.com/757x945/$p1/$p2/$p3/$hash.jpg"
        val url736 = "https://i.pinimg.com/736x/$p1/$p2/$p3/$hash.jpeg"
        val url474 = "https://i.pinimg.com/474x/$p1/$p2/$p3/$hash.webp"
        val url236 = "https://i.pinimg.com/236x/$p1/$p2/$p3/$hash.jpg"
        val urlOrig = "https://i.pinimg.com/originals/$p1/$p2/$p3/$hash.jpg"

        val key757 = MediaClassifier.deduplicationKey(url757)
        val key736 = MediaClassifier.deduplicationKey(url736)
        val key474 = MediaClassifier.deduplicationKey(url474)
        val key236 = MediaClassifier.deduplicationKey(url236)
        val keyOrig = MediaClassifier.deduplicationKey(urlOrig)

        val expectedKey = "pinimg:${hash.lowercase()}"
        assertEquals(expectedKey, key757)
        assertEquals(expectedKey, key736)
        assertEquals(expectedKey, key474)
        assertEquals(expectedKey, key236)
        assertEquals(expectedKey, keyOrig)

        // All should resolve to originals
        val res736 = MediaClassifier.resolveOriginalMedia(url736)
        assertEquals("https://i.pinimg.com/originals/$p1/$p2/$p3/$hash.jpg", res736.mediaUrl)
        assertEquals(url736, res736.thumbnailUrl)
    }

    @Test
    fun testResponsiveRasterFormatVariantsDeduplication() {
        // WordPress / Shopify / CDN resize suffixes and format variants
        val base = "https://example.com/wp-content/uploads/2024/05/hero"
        val wpJpg = "$base-736x918.jpg"
        val wpWebp = "$base-757x945.webp"
        val wpOrig = "$base.jpeg"

        val key1 = MediaClassifier.deduplicationKey(wpJpg)
        val key2 = MediaClassifier.deduplicationKey(wpWebp)
        val key3 = MediaClassifier.deduplicationKey(wpOrig)

        assertEquals(key3, key1)
        assertEquals(key3, key2)

        // CDN folder dimensions
        val cdnThumb = "https://images.example.com/236x/products/shoe.webp?w=236&format=webp"
        val cdnLarge = "https://images.example.com/736x/products/shoe.jpg?w=736&format=jpg"
        val cdnKey1 = MediaClassifier.deduplicationKey(cdnThumb)
        val cdnKey2 = MediaClassifier.deduplicationKey(cdnLarge)
        assertEquals(cdnKey2, cdnKey1)
    }

    @Test
    fun testDeduplicateScrapedItemsCollapsesResolutionAndFormatVariants() {
        val hash = "2d4c7a99e43de785bde6214ec042e947"
        val item1 = ScrapedMediaItem(
            id = "item_1",
            url = "https://i.pinimg.com/736x/2d/4c/7a/$hash.jpeg",
            title = "Aishwarya Rai Portrait",
            isVideo = false,
            resolutionHint = "736x1227",
            thumbnailUrl = "https://i.pinimg.com/736x/2d/4c/7a/$hash.jpeg",
            provenance = MediaProvenance(extractorEngine = "Static HTML (DOM Scrape)")
        )
        val item2 = ScrapedMediaItem(
            id = "item_2",
            url = "https://i.pinimg.com/236x/2d/4c/7a/$hash.jpeg",
            title = "Aishwarya Rai Portrait",
            isVideo = false,
            resolutionHint = "236x393",
            thumbnailUrl = "https://i.pinimg.com/236x/2d/4c/7a/$hash.jpeg",
            provenance = MediaProvenance(extractorEngine = "Browser Chromium (Network Intercept)")
        )
        val item3 = ScrapedMediaItem(
            id = "item_3",
            url = "https://i.pinimg.com/474x/2d/4c/7a/$hash.webp",
            title = "Aishwarya Rai Portrait",
            isVideo = false,
            resolutionHint = "474x790",
            thumbnailUrl = "https://i.pinimg.com/474x/2d/4c/7a/$hash.webp",
            provenance = MediaProvenance(extractorEngine = "DOM Scrape")
        )

        val deduplicated = MediaClassifier.deduplicateScrapedItems(listOf(item1, item2, item3))
        assertEquals(1, deduplicated.size)

        val winner = deduplicated[0]
        // Master original URL should be resolved
        assertEquals("https://i.pinimg.com/originals/2d/4c/7a/$hash.jpg", winner.url)
        // Highest resolution hint should be preserved
        assertEquals("736x1227", winner.resolutionHint)
        // Provenance should be merged
        assertTrue(winner.provenance.extractorEngine.contains("DOM Scrape"))
        assertTrue(winner.provenance.extractorEngine.contains("Network Intercept"))
        // Thumbnail should be present
        assertNotNull(winner.thumbnailUrl)
    }

    @Test
    fun testUserScreenshotExactDuplicateItemsAreCollapsed() {
        // From user screenshot:
        // Item 1: f732ca2684db4685ff26... JPG 757x945
        // Item 2: f732ca2684db4685ff26... JPEG 736x918
        val hash = "f732ca2684db4685ff263b65cb466ff4"
        val item1 = ScrapedMediaItem(
            id = "f7_item_1",
            url = "https://i.pinimg.com/757x945/f7/32/ca/$hash.jpg",
            title = "$hash...",
            isVideo = false,
            resolutionHint = "757x945",
            thumbnailUrl = "https://i.pinimg.com/757x945/f7/32/ca/$hash.jpg"
        )
        val item2 = ScrapedMediaItem(
            id = "f7_item_2",
            url = "https://i.pinimg.com/736x/f7/32/ca/$hash.jpeg",
            title = "$hash...",
            isVideo = false,
            resolutionHint = "736x918",
            thumbnailUrl = "https://i.pinimg.com/736x/f7/32/ca/$hash.jpeg"
        )

        val deduplicated = MediaClassifier.deduplicateScrapedItems(listOf(item1, item2))
        assertEquals(1, deduplicated.size)
        val winner = deduplicated.first()
        assertEquals("https://i.pinimg.com/originals/f7/32/ca/$hash.jpg", winner.url)
        assertEquals("757x945", winner.resolutionHint)
    }

    @Test
    fun testCompareMediaQualityPrefersOriginalsAndHigherResolution() {
        val lowRes = ScrapedMediaItem(
            id = "low",
            url = "https://example.com/images/hero-236x150.webp",
            title = "Hero",
            resolutionHint = "236x150",
            sizeBytes = 15000L
        )
        val highRes = ScrapedMediaItem(
            id = "high",
            url = "https://example.com/images/hero-1920x1080.jpg",
            title = "Hero",
            resolutionHint = "1920x1080",
            sizeBytes = 350000L
        )

        // highRes quality should be strictly greater than lowRes
        assertTrue(MediaClassifier.compareMediaQuality(highRes, lowRes) > 0)
        assertTrue(MediaClassifier.compareMediaQuality(lowRes, highRes) < 0)
    }

    @Test
    fun testCloudflareAndCdnTransformsDeduplication() {
        val cdnOriginal = "https://images.example.com/products/watch.png"
        val cdnOptimized = "https://images.example.com/cdn-cgi/image/width=800,quality=75,format=auto/products/watch.png"
        val cdnThumb = "https://images.example.com/cdn-cgi/image/w_200,h_200,f_auto/products/watch.png"

        val keyOrig = MediaClassifier.deduplicationKey(cdnOriginal)
        val keyOpt = MediaClassifier.deduplicationKey(cdnOptimized)
        val keyThumb = MediaClassifier.deduplicationKey(cdnThumb)

        assertEquals(keyOrig, keyOpt)
        assertEquals(keyOrig, keyThumb)
    }

    @Test
    fun testDuplicateDownloadItemsAreFilteredOut() {
        val item1 = com.amresalehin.emregallery.data.MediaInboxItem(
            id = "item_1",
            title = "sample.jpg",
            localUri = "/data/downloads/sample.jpg",
            sourceUrl = "https://example.com/sample.jpg",
            isVideo = false,
            sizeBytes = 1000L
        )
        val duplicateItem = com.amresalehin.emregallery.data.MediaInboxItem(
            id = "item_1_alt",
            title = "sample.jpg",
            localUri = "/data/downloads/sample.jpg",
            sourceUrl = "https://example.com/sample.jpg",
            isVideo = false,
            sizeBytes = 1000L
        )

        val list = listOf(item1)
        val updated = list.filter {
            it.id != duplicateItem.id && it.sourceUrl != duplicateItem.sourceUrl && it.localUri != duplicateItem.localUri
        } + duplicateItem

        // Should have exactly 1 item (replaced/deduplicated), not 2 copies
        assertEquals(1, updated.size)
    }

    @Test
    fun testMediaRepositoryRejectsXmlAndNonMediaFiles() {
        val nonMediaSamples = listOf(
            Pair("AndroidManifest.xml", "text/xml"),
            Pair("strings.xml", "application/xml"),
            Pair("document.pdf", "application/pdf"),
            Pair("archive.zip", "application/zip"),
            Pair("notes.txt", "text/plain"),
            Pair("payload.json", "application/json"),
            Pair("app.apk", "application/vnd.android.package-archive"),
            Pair("script.js", "text/javascript"),
            Pair("style.css", "text/css"),
            Pair(".nomedia", null)
        )

        for ((name, mime) in nonMediaSamples) {
            org.junit.Assert.assertFalse(
                "Expected $name ($mime) to be rejected by isSupportedMedia",
                com.amresalehin.emregallery.data.MediaRepository.isSupportedMedia(name, mime, isVideo = false)
            )
            org.junit.Assert.assertFalse(
                "Expected $name ($mime) to be rejected as video by isSupportedMedia",
                com.amresalehin.emregallery.data.MediaRepository.isSupportedMedia(name, mime, isVideo = true)
            )
        }

        val validMediaSamples = listOf(
            Pair("photo.jpg", "image/jpeg"),
            Pair("picture.png", "image/png"),
            Pair("graphic.webp", "image/webp"),
            Pair("camera.heic", "image/heif"),
            Pair("video.mp4", "video/mp4"),
            Pair("clip.webm", "video/webm")
        )

        for ((name, mime) in validMediaSamples) {
            val isVid = name.endsWith(".mp4") || name.endsWith(".webm")
            org.junit.Assert.assertTrue(
                "Expected $name ($mime) to be accepted by isSupportedMedia",
                com.amresalehin.emregallery.data.MediaRepository.isSupportedMedia(name, mime, isVideo = isVid)
            )
        }
    }

    @Test
    fun testMediaClassifierRejectsSvgXmlDataUriPlaceholders() {
        // LiteSpeed / WordPress placeholder transparent rectangle SVG
        val svgXmlDataUri = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMDAiIGhlaWdodD0iMTY4IiB2aWV3Qm94PSIwIDAgMzAwIDE2OCI+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgc3R5bGU9ImZpbGw6I2NmZDRkYjtmaWxsLW9wYWNpdHk6IDAuMTsiLz48L3N2Zz4="
        org.junit.Assert.assertFalse(
            "Expected SVG XML placeholder data URI to be rejected",
            MediaClassifier.isSubstantialDataUri(svgXmlDataUri)
        )
        org.junit.Assert.assertFalse(
            "Expected SVG XML placeholder data URI to be invalid media",
            MediaClassifier.isValidMedia(svgXmlDataUri)
        )
    }

    @Test
    fun testYouTubeThumbnailDeduplicationAndResolutionFolding() {
        val oar2Url = "https://i.ytimg.com/vi/FaEeQPmv1D4/oar2.jpg"
        val frame0_268 = "https://i.ytimg.com/vi/FaEeQPmv1D4/frame0.jpg?sqp=-oaymwEdCJUDENAFSFWQAgHyq4qpAw8IARUAAIhCcAHAAQ==&rs=AOn4CLB..."
        val frame0_270 = "https://i.ytimg.com/vi/FaEeQPmv1D4/frame0.jpg?sqp=-oaymwEdCK4DENAFSFWQAgHyq4qpAw8IARUAAIhCcAHAAQ==&rs=AOn4CLB..."

        // All share the same canonical YouTube thumbnail key
        val key1 = MediaClassifier.deduplicationKey(oar2Url)
        val key2 = MediaClassifier.deduplicationKey(frame0_268)
        val key3 = MediaClassifier.deduplicationKey(frame0_270)

        assertEquals("ytthumb:${"FaEeQPmv1D4".lowercase(java.util.Locale.ROOT)}", key1)
        assertEquals(key1, key2)
        assertEquals(key1, key3)

        val item1 = ScrapedMediaItem(
            id = "item_1",
            url = oar2Url,
            title = "oar2.jpg",
            isVideo = false,
            resolutionHint = "405x720",
            category = MediaCategory.IMAGES
        )
        val item2 = ScrapedMediaItem(
            id = "item_2",
            url = frame0_268,
            title = "frame0.jpg",
            isVideo = false,
            resolutionHint = "268x480",
            category = MediaCategory.IMAGES
        )
        val item3 = ScrapedMediaItem(
            id = "item_3",
            url = frame0_270,
            title = "frame0.jpg",
            isVideo = false,
            resolutionHint = "270x480",
            category = MediaCategory.IMAGES
        )

        val deduplicated = MediaClassifier.deduplicateScrapedItems(listOf(item1, item2, item3))
        // Multiple frame and size variants must collapse to exactly 1 highest-quality thumbnail
        assertEquals(1, deduplicated.size)
        // High resolution 405x720 must be selected over 268x480 or 270x480
        assertEquals("405x720", deduplicated[0].resolutionHint)
    }

    @Test
    fun testVideoPosterFoldingLeavesOnlyVideo() {
        val videoItem = ScrapedMediaItem(
            id = "video_1",
            url = "https://rr1---sn-uxa-i5ne.googlevideo.com/videoplayback?expire=123&id=FaEeQPmv1D4",
            title = "Abba Harmonium Bajate...",
            isVideo = true,
            category = MediaCategory.VIDEOS,
            format = "WEBM",
            resolutionHint = "720x1280",
            thumbnailUrl = "https://i.ytimg.com/vi/FaEeQPmv1D4/hqdefault.jpg"
        )

        val oar2PosterItem = ScrapedMediaItem(
            id = "img_oar2",
            url = "https://i.ytimg.com/vi/FaEeQPmv1D4/oar2.jpg",
            title = "oar2.jpg",
            isVideo = false,
            category = MediaCategory.IMAGES,
            resolutionHint = "405x720"
        )

        val frame0PosterItem = ScrapedMediaItem(
            id = "img_frame0",
            url = "https://i.ytimg.com/vi/FaEeQPmv1D4/frame0.jpg?sqp=abc",
            title = "frame0.jpg",
            isVideo = false,
            category = MediaCategory.IMAGES,
            resolutionHint = "270x480"
        )

        val result = MediaClassifier.deduplicateScrapedItems(listOf(videoItem, oar2PosterItem, frame0PosterItem))

        // Standalone poster/storyboard image duplicates of the video must be folded into the video
        assertEquals(1, result.size)
        val finalVideo = result[0]
        assertTrue(finalVideo.isVideo)
        assertEquals("Abba Harmonium Bajate...", finalVideo.title)
        // Thumbnail should be upgraded to oar2.jpg (405x720) from the folded poster item
        assertTrue(finalVideo.thumbnailUrl?.contains("FaEeQPmv1D4") == true)
    }

    @Test
    fun testNonMediaEndpointsAndIframeWebPagesAreRejected() {
        val rejectedUrls = listOf(
            "https://www.youtube.com/embed/FaEeQPmv1D4",
            "https://www.youtube.com/shorts/FaEeQPmv1D4",
            "https://www.youtube.com/watch?v=FaEeQPmv1D4",
            "https://www.youtube.com/api/stats/playback?ns=yt&cpn=123",
            "https://play.google.com/log?format=json&has_webp=1",
            "https://i.ytimg.com/generate_204",
            "https://accounts.google.com/ServiceLogin?service=youtube",
            "https://example.com/embed/player_widget",
            "https://example.com/tracking/pixel"
        )

        for (url in rejectedUrls) {
            org.junit.Assert.assertFalse(
                "Expected $url to be rejected by isValidMedia",
                MediaClassifier.isValidMedia(url)
            )
        }
    }

    @Test
    fun testStructuredJsonLdGraphExtractionAndThumbnailRelationship() {
        val jsonLd = """
            {
              "@context": "https://schema.org",
              "@graph": [
                {
                  "@type": "NewsArticle",
                  "headline": "Deep Sea Expedition Footage",
                  "author": { "@type": "Person", "name": "Dr. Sylvia" },
                  "video": {
                    "@type": "VideoObject",
                    "name": "Mariana Trench 4K Dive",
                    "contentUrl": "https://cdn.example.com/media/stream_delivery?id=998877",
                    "encodingFormat": "video/mp4",
                    "duration": "PT2M15S",
                    "contentSize": "45 MB",
                    "width": { "@type": "QuantitativeValue", "value": 3840 },
                    "height": { "@type": "QuantitativeValue", "value": 2160 },
                    "thumbnailUrl": [
                      "https://cdn.example.com/thumbs/dive_small.jpg",
                      "https://cdn.example.com/thumbs/dive_hd.jpg"
                    ],
                    "encoding": [
                      {
                        "@type": "VideoObject",
                        "contentUrl": "https://cdn.example.com/videos/dive_1080p.mp4",
                        "encodingFormat": "video/mp4",
                        "width": 1920,
                        "height": 1080
                      },
                      {
                        "@type": "VideoObject",
                        "contentUrl": "https://cdn.example.com/videos/dive_2160p.mp4",
                        "encodingFormat": "video/mp4",
                        "width": 3840,
                        "height": 2160
                      }
                    ]
                  }
                }
              ]
            }
        """.trimIndent()

        val baseUrl = "https://example.com/articles/deep-sea"
        val resources = com.amresalehin.emregallery.data.MediaCaptureEngine.extractJsonLdResources(jsonLd, baseUrl)
        assertEquals(1, resources.size)

        val videoRes = resources.first()
        assertEquals("video", videoRes.mediaTypeHint)
        assertEquals("Mariana Trench 4K Dive", videoRes.titleHint)
        assertEquals("Dr. Sylvia", videoRes.authorHint)
        assertEquals(135L, videoRes.durationSeconds)
        assertEquals(3840, videoRes.width)
        assertEquals(2160, videoRes.height)
        assertEquals("3840x2160", videoRes.resolutionHint)
        assertTrue(videoRes.thumbnailUrl?.contains("dive_") == true)

        val builtItem = com.amresalehin.emregallery.data.MediaCaptureEngine.buildMediaItemFromResource(videoRes, baseUrl)
        assertNotNull(builtItem)
        assertTrue(builtItem!!.isVideo)
        assertEquals(MediaCategory.VIDEOS, builtItem.category)
        assertEquals("MP4", builtItem.format)
        assertEquals("Mariana Trench 4K Dive", builtItem.title)
        assertEquals("3840x2160", builtItem.resolutionHint)
        // Highest-quality variant (2160p) should be selected over 1080p
        assertEquals("https://cdn.example.com/videos/dive_2160p.mp4", builtItem.url)
        assertNotNull(builtItem.thumbnailUrl)

        // If a standalone thumbnail image from the same video is scraped from DOM, deduplicateScrapedItems must fold it into the video
        val standaloneThumb = ScrapedMediaItem(
            id = "dom_thumb",
            url = "https://cdn.example.com/thumbs/dive_hd.jpg",
            title = "dive_hd.jpg",
            isVideo = false,
            category = MediaCategory.IMAGES,
            resolutionHint = "1280x720"
        )
        val reconciled = MediaClassifier.deduplicateScrapedItems(listOf(standaloneThumb, builtItem))
        assertEquals(1, reconciled.size)
        assertTrue(reconciled.first().isVideo)
        assertEquals("https://cdn.example.com/thumbs/dive_hd.jpg", reconciled.first().thumbnailUrl)
    }

    @Test
    fun testStaticHtmlStructuredElementDiscoveryGroupsPictureVideoAndLinks() {
        val html = """
            <!DOCTYPE html>
            <html>
            <head>
                <title>Structured Media Showcase</title>
                <meta property="og:title" content="Keynote Presentation" />
                <meta property="og:video" content="https://cdn.example.com/videos/keynote_1080p.mp4" />
                <meta property="og:video:type" content="video/mp4" />
                <meta property="og:video:width" content="1920" />
                <meta property="og:video:height" content="1080" />
                <meta property="og:image" content="https://cdn.example.com/posters/keynote_poster.jpg" />
                <script type="application/ld+json">
                {
                  "@context": "https://schema.org",
                  "@type": "AudioObject",
                  "name": "Keynote Podcast Episode",
                  "contentUrl": "https://cdn.example.com/audio/stream?track=42",
                  "encodingFormat": "audio/mp4",
                  "duration": "PT45M"
                }
                </script>
            </head>
            <body>
                <picture>
                    <source type="image/avif" srcset="https://cdn.example.com/gallery/photo_small.avif 640w, https://cdn.example.com/gallery/photo_4k.avif 3840w" />
                    <source type="image/webp" srcset="https://cdn.example.com/gallery/photo_hd.webp 1920w" />
                    <img src="https://cdn.example.com/gallery/photo_fallback.jpg" alt="Alpine Sunrise" width="1920" height="1080" />
                </picture>

                <a href="https://cdn.example.com/downloads/masterpiece_full.png" title="Masterpiece Original">
                    <img src="https://cdn.example.com/thumbs/masterpiece_preview.jpg" alt="Masterpiece Artwork" width="400" height="300" />
                </a>

                <div class="video-card" data-trailer="https://cdn.example.com/trailers/teaser.mp4" data-main-thumb="https://cdn.example.com/trailers/teaser_thumb.jpg" title="Official Teaser">
                    <img src="https://cdn.example.com/trailers/teaser_thumb.jpg" alt="Teaser" />
                </div>
            </body>
            </html>
        """.trimIndent()

        val baseUrl = "https://example.com/showcase"
        val doc = org.jsoup.Jsoup.parse(html, baseUrl)
        val scraper = com.amresalehin.emregallery.data.StaticMediaScraper()
        val items = scraper.parseDocumentMedia(doc, baseUrl)

        // Expected distinct logical media resources:
        // 1. OpenGraph video (with keynote_poster.jpg paired as thumbnail, NOT emitted as a separate image)
        // 2. JSON-LD AudioObject (extensionless URL classified as AUDIO via encodingFormat/typeHint)
        // 3. <picture> element (collapsed to 1 image resource with highest-res 3840w AVIF URL, Alpine Sunrise title, fallback thumb)
        // 4. <a href="masterpiece_full.png"><img src="masterpiece_preview.jpg"></a> (collapsed to 1 image resource pointing to masterpiece_full.png with masterpiece_preview.jpg as thumbnail)
        // 5. [data-trailer] video card (collapsed to 1 video resource with teaser_thumb.jpg paired as thumbnail)
        assertEquals(5, items.size)

        val ogVideo = items.first { it.url.contains("keynote_1080p.mp4") }
        assertTrue(ogVideo.isVideo)
        assertEquals("https://cdn.example.com/posters/keynote_poster.jpg", ogVideo.thumbnailUrl)
        assertEquals("1920x1080", ogVideo.resolutionHint)

        val podcastAudio = items.first { it.url.contains("audio/stream") }
        assertTrue(podcastAudio.isAudio)
        assertEquals(MediaCategory.AUDIO, podcastAudio.category)
        assertEquals("Keynote Podcast Episode", podcastAudio.title)

        val pictureItem = items.first { it.title == "Alpine Sunrise" }
        assertEquals("https://cdn.example.com/gallery/photo_4k.avif", pictureItem.url)
        assertEquals("AVIF", pictureItem.format)
        assertEquals("https://cdn.example.com/gallery/photo_fallback.jpg", pictureItem.thumbnailUrl)

        val linkedArtwork = items.first { it.url.contains("masterpiece_full.png") }
        assertEquals("Masterpiece Artwork", linkedArtwork.title)
        assertEquals("https://cdn.example.com/thumbs/masterpiece_preview.jpg", linkedArtwork.thumbnailUrl)

        val trailerVideo = items.first { it.url.contains("teaser.mp4") }
        assertTrue(trailerVideo.isVideo)
        assertEquals("Official Teaser", trailerVideo.title)
        assertEquals("https://cdn.example.com/trailers/teaser_thumb.jpg", trailerVideo.thumbnailUrl)
    }

    @Test
    fun testContextAwareClassificationAndMetadataReconciliation() {
        // 1. Query-param & typeHint classification for extensionless endpoints
        val extlessVideo = MediaClassifier.classify(
            url = "https://video-delivery.example.net/playback?id=abc&mime=video%2Fmp4",
            mimeHint = null,
            typeHint = null
        )
        assertTrue(extlessVideo.isVideo)
        assertEquals(MediaCategory.VIDEOS, extlessVideo.category)
        assertEquals("MP4", extlessVideo.format)

        val extlessAudioByTypeHint = MediaClassifier.classify(
            url = "https://audio-cdn.example.net/stream/99881122",
            mimeHint = null,
            typeHint = "AudioObject"
        )
        assertTrue(extlessAudioByTypeHint.isAudio)
        assertEquals(MediaCategory.AUDIO, extlessAudioByTypeHint.category)

        val dashAudio = MediaClassifier.classify("https://v.redd.it/k8m9n0p/DASH_AUDIO_128.mp4")
        assertTrue(dashAudio.isAudio)
        assertEquals(MediaCategory.AUDIO, dashAudio.category)

        // 2. Metadata reconciliation between Network Intercept item (has sizeBytes, generic title/resolution)
        // and DOM/JSON-LD item (has semantic title, real dimensions, poster thumbnail)
        val networkInterceptItem = ScrapedMediaItem(
            id = "net_101",
            url = "https://cdn.example.com/videos/9f8e7d6c5b4a321098765432.mp4",
            title = "9f8e7d6c5b4a321098765432.mp4",
            isVideo = true,
            category = MediaCategory.VIDEOS,
            format = "MP4",
            mimeType = "video/mp4",
            resolutionHint = "Network",
            sizeBytes = 18_500_000L,
            provenance = MediaProvenance(extractorEngine = "Browser Chromium (Network Intercept)"),
            downloadHeaders = mapOf("Referer" to "https://example.com/watch")
        )

        val domStructuredItem = ScrapedMediaItem(
            id = "dom_102",
            url = "https://cdn.example.com/videos/9f8e7d6c5b4a321098765432.mp4",
            title = "Northern Lights Time-Lapse in Norway",
            isVideo = true,
            category = MediaCategory.VIDEOS,
            format = "MP4",
            mimeType = "video/mp4",
            resolutionHint = "1920x1080",
            thumbnailUrl = "https://cdn.example.com/posters/aurora_thumb.jpg",
            provenance = MediaProvenance(extractorEngine = "Browser Chromium (JSON-LD)", domSelector = "script[type=application/ld+json]"),
            metadata = mapOf("duration_sec" to "84", "author" to "Nordic Sky"),
            downloadHeaders = mapOf("Cookie" to "session=xyz")
        )

        val mergedList = MediaClassifier.deduplicateScrapedItems(listOf(networkInterceptItem, domStructuredItem))
        assertEquals(1, mergedList.size)
        val reconciled = mergedList.first()

        // Preserves initial item ID for UI stability
        assertEquals("net_101", reconciled.id)
        // Reconciles semantic title over hex hash filename
        assertEquals("Northern Lights Time-Lapse in Norway", reconciled.title)
        // Reconciles dimensional resolutionHint over "Network"
        assertEquals("1920x1080", reconciled.resolutionHint)
        // Preserves sizeBytes from network intercept
        assertEquals(18_500_000L, reconciled.sizeBytes)
        // Preserves poster thumbnail from structured DOM/JSON-LD
        assertEquals("https://cdn.example.com/posters/aurora_thumb.jpg", reconciled.thumbnailUrl)
        // Merges provenance, metadata, and download headers
        assertTrue(reconciled.provenance.extractorEngine.contains("Network Intercept"))
        assertTrue(reconciled.provenance.extractorEngine.contains("JSON-LD"))
        assertEquals("84", reconciled.metadata["duration_sec"])
        assertEquals("https://example.com/watch", reconciled.downloadHeaders["Referer"])
        assertEquals("session=xyz", reconciled.downloadHeaders["Cookie"])
    }
}

